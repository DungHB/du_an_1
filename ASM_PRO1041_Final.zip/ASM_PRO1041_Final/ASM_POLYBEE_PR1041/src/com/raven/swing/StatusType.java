package com.raven.swing;

public enum StatusType {
    PENDING, APPROVED, REJECT
}
