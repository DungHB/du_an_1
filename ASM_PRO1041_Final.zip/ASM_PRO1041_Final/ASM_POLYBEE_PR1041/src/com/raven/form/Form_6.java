package com.raven.form;

import com.asm.polybee.model.HoaDon;
import com.asm.polybee.model.HoaDonChiTiet;
import com.asm.polybee.model.NhanVien;
import com.asm.polybee.repository.HoaDonRepository;
import com.asm.polybee.service.HoaDonChiTietService;
import com.asm.polybee.service.HoaDonService;
import com.asm.polybee.service.Impl.HoaDonChiTietImpl;
import com.asm.polybee.service.Impl.HoaDonServiceImpl;
import com.asm.polybee.service.Impl.NhanVienServiceImpl;
import com.asm.polybee.service.NhanVienService;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Form_6 extends javax.swing.JPanel {

    private HoaDonService hoaDonService = new HoaDonServiceImpl();
    private HoaDonChiTietService hoaDonChiTietService = new HoaDonChiTietImpl();
    private HoaDonRepository hoaDonRepository = new HoaDonRepository();

    private NhanVienService nhanVienService = new NhanVienServiceImpl();
    DefaultTableModel defaultTableModel;
    Map<String, String> nhanVienMap = new LinkedHashMap<>();

    /**
     * Creates new form Form_6
     */
    public Form_6() {
        initComponents();
        loadDataHoaDon();
        loadCBB();
        loadTheLast30Day();

    }

    void loadDataHoaDon() {
        List<HoaDon> listHoaDons = hoaDonService.getAllViewTable();
        defaultTableModel = (DefaultTableModel) tbl_hoaDon.getModel();
        defaultTableModel.setRowCount(0);

        for (HoaDon hoaDon : listHoaDons) {
            defaultTableModel.addRow(new Object[]{
                hoaDon.getIdHoaDon(),
                hoaDon.getMaHoaDon(),
                hoaDon.getNgayTao(),
                hoaDon.getTrangThai(),
                hoaDon.getTongTien(),
                hoaDon.getTenNhanVien(),
                hoaDon.getTenKhachHang()
            }
            );
            Long tongTien = hoaDon.getTongTien();
        }
    }

    void loadDataGioHang() {
        int row = tbl_hoaDon.getSelectedRow();

        String idHoaDon = tbl_hoaDon.getValueAt(row, 0).toString();
        List<HoaDonChiTiet> dsSanPhamTrongGioHang = hoaDonChiTietService.getAllGioHangByIDHoaDon(idHoaDon);
        defaultTableModel = (DefaultTableModel) tbl_dsGioHang.getModel();
        defaultTableModel.setRowCount(0);

        for (HoaDonChiTiet hoaDonChiTiet : dsSanPhamTrongGioHang) {
            Long thanhTien = hoaDonChiTiet.getDonGia() * hoaDonChiTiet.getSoLuong();
            defaultTableModel.addRow(new Object[]{
                hoaDonChiTiet.getTenSanPham(),
                hoaDonChiTiet.getDonGia(),
                hoaDonChiTiet.getSize(),
                hoaDonChiTiet.getMauSac(),
                hoaDonChiTiet.getSoLuong(),
                thanhTien,
                hoaDonChiTiet.getIdHoaDonChiTiet(),
                hoaDonChiTiet.getIdSanPhamChiTiet()
            });

        }
    }

    void loadCBB() {
        List<NhanVien> nhanViens = nhanVienService.getAll();
        nhanVienMap.put("Tất cả", "Tất cả"); // Thêm giá trị "Tất cả"

        for (NhanVien nhanVien : nhanViens) {
            NhanVien nhanVienList = nhanVienService.getNhanVienByIdNhanVien(nhanVien.getIdnhanVien());
            nhanVienMap.put(nhanVienList.getTenNhanVien(), nhanVienList.getIdnhanVien());
        }

        DefaultComboBoxModel<String> modelNhanVien = new DefaultComboBoxModel<>(nhanVienMap.keySet().toArray(new String[0]));
        cbb_nhanVien.setModel(modelNhanVien);
    }

    void loadTheLast30Day() {
        LocalDate ngayHienTai = LocalDate.now();
        LocalDate ngayBatDau = ngayHienTai.minusDays(30);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String ngayThangNamHienTai = ngayHienTai.format(formatter);
        String ngayThangNamBatDau = ngayBatDau.format(formatter);
        txt_ketThuc.setText(ngayThangNamHienTai);
        txt_batDau.setText(ngayThangNamBatDau);
    }

    void locTrangThaiHD2() {
        LocalDate ngayTaoLocalDate = LocalDate.parse(txt_batDau.getText());
        Date batDau = Date.valueOf(ngayTaoLocalDate);

        LocalDate ngayKTLocalDate = LocalDate.parse(txt_ketThuc.getText());
        Date ketThuc = Date.valueOf(ngayKTLocalDate);

        String tenNhanVienLoc = cbb_nhanVien.getSelectedItem().toString();
        String idNhanVienLoc = nhanVienMap.get(tenNhanVienLoc);

        List<HoaDon> hoaDonLocs;
        if (idNhanVienLoc.equalsIgnoreCase("Tất cả")) {
            hoaDonLocs = hoaDonRepository.getHoaDonByConditions2(batDau, ketThuc);
        } else {
            hoaDonLocs = hoaDonRepository.getHoaDonByConditions(batDau, ketThuc, idNhanVienLoc);
        }

        defaultTableModel = (DefaultTableModel) tbl_hoaDon.getModel();
        defaultTableModel.setRowCount(0);

        Map<String, String> tenNhanVienByID = new HashMap<>();
        for (HoaDon hoaDon : hoaDonLocs) {
            String idNhanVien = hoaDon.getIdNhanVien();
            if (!tenNhanVienByID.containsKey(idNhanVien)) {
                NhanVien nhanVien = nhanVienService.getNhanVienByIdNhanVien(idNhanVien);
                tenNhanVienByID.put(idNhanVien, nhanVien.getTenNhanVien());
            }
            String tenNhanVien = tenNhanVienByID.get(idNhanVien);

           
            defaultTableModel.addRow(new Object[]{
                hoaDon.getIdHoaDon(),
                hoaDon.getMaHoaDon(),
                hoaDon.getNgayTao(),
                hoaDon.getTrangThai(),
                hoaDon.getTongTien(),
                tenNhanVien,
                hoaDon.getTenKhachHang()
            });
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_hoaDon = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        cbb_nhanVien = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txt_batDau = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_ketThuc = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_maHoaDon = new javax.swing.JTextField();
        btn_timKiem = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_dsGioHang = new javax.swing.JTable();

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tbl_hoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID hoá đơn", "Mã hoá đơn", "Ngày Tạo", "Trạng Thái", "Tổng tiền", "Nhân Viên", "Khách Hàng"
            }
        ));
        tbl_hoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_hoaDonMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_hoaDon);

        jButton2.setText("Tất cả");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        cbb_nhanVien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setText("Nhân Viên");

        jButton1.setText("Lọc");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setText("Bắt đầu");

        txt_batDau.setText("2024-01-01");
        txt_batDau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_batDauActionPerformed(evt);
            }
        });

        jLabel4.setText("Kết thúc");

        txt_ketThuc.setText("2024-01-31");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_batDau, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_ketThuc, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(cbb_nhanVien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(72, 72, 72)
                        .addComponent(jButton1)))
                .addGap(16, 16, 16))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_batDau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txt_ketThuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cbb_nhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(16, 16, 16))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setText("Tìm hoá đơn");

        jLabel5.setText("Mã hoá đơn");

        btn_timKiem.setText("Tìm");
        btn_timKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(jLabel1))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_maHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(btn_timKiem)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_maHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_timKiem)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 766, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        tbl_dsGioHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Sản phẩm", "Giá", "Size", "Màu", "Số lượng", "Thành tiền", "ID HDCT", "ID SPCT"
            }
        ));
        jScrollPane3.setViewportView(tbl_dsGioHang);
        if (tbl_dsGioHang.getColumnModel().getColumnCount() > 0) {
            tbl_dsGioHang.getColumnModel().getColumn(6).setMinWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(6).setPreferredWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(6).setMaxWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(7).setMinWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(7).setPreferredWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(7).setMaxWidth(0);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void tbl_hoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_hoaDonMouseClicked
        loadDataGioHang();
    }//GEN-LAST:event_tbl_hoaDonMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        locTrangThaiHD2();
        txt_maHoaDon.setText("");
        ((DefaultTableModel) tbl_dsGioHang.getModel()).setRowCount(0);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        loadDataHoaDon();
        txt_maHoaDon.setText("");
        ((DefaultTableModel) tbl_dsGioHang.getModel()).setRowCount(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txt_batDauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_batDauActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_batDauActionPerformed

    private void btn_timKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timKiemActionPerformed
        String maHoaDon = txt_maHoaDon.getText();

        HoaDon hoaDons = hoaDonRepository.getHoaDonByMaHoaDon(maHoaDon);
        if (hoaDons != null) {
            JOptionPane.showMessageDialog(this, "Đã tìm thấy hoá đơn với mã là: " + maHoaDon);
            defaultTableModel = (DefaultTableModel) tbl_hoaDon.getModel();
            defaultTableModel.setRowCount(0);

            // Sử dụng Map để lưu trữ tên nhân viên dựa trên ID
            Map<String, String> tenNhanVienByID = new HashMap<>();

            String idNhanVien = hoaDons.getIdNhanVien();
            if (!tenNhanVienByID.containsKey(idNhanVien)) {
                NhanVien nhanVien = nhanVienService.getNhanVienByIdNhanVien(idNhanVien);
                tenNhanVienByID.put(idNhanVien, nhanVien.getTenNhanVien());
            }
            String tenNhanVien = tenNhanVienByID.get(idNhanVien);

//            defaultTableModel.addRow(new Object[]{
//                hoaDons.getIdHoaDon(),
//                hoaDons.getMaHoaDon(),
//                hoaDons.getNgayTao(),
//                hoaDons.getTrangThai(),
//                hoaDons.getTongTien(),
//                tenNhanVien // Hiển thị tên nhân viên
//            });
            Vector<Object> rowData = new Vector<>();

            rowData.add(hoaDons.getIdHoaDon());
            rowData.add(hoaDons.getMaHoaDon());
            rowData.add(hoaDons.getNgayTao());
            rowData.add(hoaDons.getTrangThai());
            rowData.add(hoaDons.getTongTien());
            rowData.add(tenNhanVien);

            defaultTableModel.addRow(rowData);

            Long tongTien = hoaDons.getTongTien();
        } else {
            JOptionPane.showMessageDialog(this, "Chưa tìm thấy hoá đơn với mã là: " + maHoaDon);
        }


    }//GEN-LAST:event_btn_timKiemActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_timKiem;
    private javax.swing.JComboBox<String> cbb_nhanVien;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tbl_dsGioHang;
    private javax.swing.JTable tbl_hoaDon;
    private javax.swing.JTextField txt_batDau;
    private javax.swing.JTextField txt_ketThuc;
    private javax.swing.JTextField txt_maHoaDon;
    // End of variables declaration//GEN-END:variables
}
