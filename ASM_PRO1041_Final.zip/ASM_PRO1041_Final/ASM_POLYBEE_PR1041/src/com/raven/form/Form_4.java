package com.raven.form;

import com.asm.polybee.model.HoaDon;
import com.asm.polybee.model.HoaDonChiTiet;
import com.asm.polybee.model.KhachHang;
import com.asm.polybee.model.MauSac;
import com.asm.polybee.model.NhanVien;
import com.asm.polybee.model.SanPham;
import com.asm.polybee.model.SanPhamChiTiet;
import com.asm.polybee.model.Size;
import com.asm.polybee.repository.ApMaGiamGiaRepository;
import com.asm.polybee.repository.PhieuGiamGiaRepository;
import com.asm.polybee.service.ChatLieuService;
import com.asm.polybee.service.HoaDonChiTietService;
import com.asm.polybee.service.HoaDonService;
import com.asm.polybee.service.Impl.ChatLieuServiceImpl;
import com.asm.polybee.service.Impl.HoaDonChiTietImpl;
import com.asm.polybee.service.Impl.HoaDonServiceImpl;
import com.asm.polybee.service.Impl.KhachHangServiceImpl;
import com.asm.polybee.service.Impl.MauSacServiceImpl;
import com.asm.polybee.service.Impl.NhanVienServiceImpl;
import com.asm.polybee.service.Impl.SanPhamChiTietServiceImpl;
import com.asm.polybee.service.Impl.SanPhamServiceImpl;
import com.asm.polybee.service.Impl.SizeServiceImpl;
import com.asm.polybee.service.KhachHangService;
import com.asm.polybee.service.MauSacService;
import com.asm.polybee.service.NhanVienService;
import com.asm.polybee.service.SanPhamChiTietService;
import com.asm.polybee.service.SanPhamService;
import com.asm.polybee.service.SizeService;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Form_4 extends javax.swing.JPanel {

    private static NhanVien currentNhanVien;

    public static NhanVien getCurrentNhanVien() {
        return currentNhanVien;
    }

    public static void setCurrentNhanVien(NhanVien currentNhanVien) {
        Form_4.currentNhanVien = currentNhanVien;
    }

    String idNhanVien = currentNhanVien.getIdnhanVien();

    DefaultTableModel defaultTableModel;
    private SanPhamService sanPhamService = new SanPhamServiceImpl();
    private KhachHangService khachHangService = new KhachHangServiceImpl();
    private HoaDonService hoaDonService = new HoaDonServiceImpl();
    private NhanVienService nhanVienService = new NhanVienServiceImpl();
    private SanPhamChiTietService sanPhamChiTietService = new SanPhamChiTietServiceImpl();
    private SizeService sizeService = new SizeServiceImpl();
    private MauSacService mauSacService = new MauSacServiceImpl();
    private ChatLieuService chatLieuService = new ChatLieuServiceImpl();
    private HoaDonChiTietService hoaDonChiTietService = new HoaDonChiTietImpl();
    private PhieuGiamGiaRepository phieuGiamGiaRepository = new PhieuGiamGiaRepository();
    private ApMaGiamGiaRepository apMaGiamGiaRepository = new ApMaGiamGiaRepository();

    List<SanPham> sanPhams = sanPhamService.getAll();
    List<Size> sizes = sizeService.getAll();
    List<MauSac> mauSacs = mauSacService.getAll();
    private int currentPage = 1;
    private int pageSize = 3;

    /**
     * Creates new form Form_4
     */
    public Form_4() {
        initComponents();
        loadDataDSSanPham();
        loadDataHoaDonCho();
        rb_vangLai.setSelected(true);
        prev();
        next();
    }

    void prev() {
        if (this.currentPage <= 1) {
            this.btn_prevPage.setEnabled(false);
        } else {
            this.btn_prevPage.setEnabled(true);
        }
    }

    void next() {
        int countSP = sanPhamChiTietService.getCountSPCT();
        int maxSize = countSP / pageSize;
        int remainder = countSP % pageSize;
        if (remainder > 0) {
            maxSize++;
        }

        if (currentPage >= maxSize) {

            btn_nextPage.setEnabled(false);

        } else {
            btn_nextPage.setEnabled(true);
        }
    }
    void loadDataGioHang() {
        int row = tbl_hoaDonCho.getSelectedRow();

        String idHoaDon = tbl_hoaDonCho.getValueAt(row, 0).toString();
        List<HoaDonChiTiet> dsSanPhamTrongGioHang = hoaDonChiTietService.getAllGioHangByIDHoaDon(idHoaDon);
        defaultTableModel = (DefaultTableModel) tbl_dsGioHang.getModel();
        defaultTableModel.setRowCount(0);

        for (HoaDonChiTiet hoaDonChiTiet : dsSanPhamTrongGioHang) {
            Long thanhTien = hoaDonChiTiet.getDonGia() * hoaDonChiTiet.getSoLuong();
            defaultTableModel.addRow(new Object[]{
                hoaDonChiTiet.getTenSanPham(),
                hoaDonChiTiet.getDonGia(),
                hoaDonChiTiet.getSize(),
                hoaDonChiTiet.getMauSac(),
                hoaDonChiTiet.getTenChatLieu(),
                hoaDonChiTiet.getSoLuong(),
                thanhTien,
                hoaDonChiTiet.getIdHoaDonChiTiet(),
                hoaDonChiTiet.getIdSanPhamChiTiet()
            });

        }
    }

    void loadThanhTien() {
        int row = tbl_hoaDonCho.getSelectedRow();

        String idHoaDon = tbl_hoaDonCho.getValueAt(row, 0).toString();
        HoaDon hoaDon = hoaDonService.getHoaDonByMaHoaDon(idHoaDon);

        String idPhieuGiamGia = apMaGiamGiaRepository.getIdPhieuGiamGiaByIdHoaDon(idHoaDon);

        txt_tongTien.setText(String.valueOf(hoaDon.getTongTien()));
        return;

    }

    void loadDataHoaDonCho() {

        List<HoaDon> hoaDonDangCho = hoaDonService.getHoaDonByTrangThai("Đang chờ");
        defaultTableModel = (DefaultTableModel) tbl_hoaDonCho.getModel();
        defaultTableModel.setRowCount(0);

        for (HoaDon hoaDon : hoaDonDangCho) {

            defaultTableModel.addRow(new Object[]{
                hoaDon.getIdHoaDon(),
                hoaDon.getNgayTao(),
                hoaDon.getTrangThai()
            });

        }
    }

    void loadDataDSSanPham() {
        List<SanPhamChiTiet> dsSanPham = sanPhamChiTietService.getAllSanPhamChiTietViewTable((currentPage - 1) * pageSize, pageSize);
        defaultTableModel = (DefaultTableModel) tbl_danhsachSP.getModel();
        defaultTableModel.setRowCount(0);

        dsSanPham.forEach(sanPhamChiTiet -> {
            defaultTableModel.addRow(new Object[]{
                sanPhamChiTiet.getTenSanPham(),
                sanPhamChiTiet.getTenMauSac(),
                sanPhamChiTiet.getSize(),
                sanPhamChiTiet.getTenChatLieu(),
                sanPhamChiTiet.getGia(),
                sanPhamChiTiet.getSoLuong(),
                sanPhamChiTiet.getIdSanPhamChiTiet(),});
        });
    }

    private String taoMaHoaDon() {
        // Định dạng cho phần số ngẫu nhiên
        String format = "00000";

        // Lấy ngày và giờ hiện tại
        LocalDateTime now = LocalDateTime.now();

        // Định dạng cho phần thời gian
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

        // Tạo phần thời gian từ ngày và giờ hiện tại
        String part1 = now.format(formatter);

        // Tạo phần số ngẫu nhiên
        String part2 = String.format("%05d", new Random().nextInt(100000));

        // Ghép các phần lại với nhau để tạo mã hóa đơn
        String maHoaDon = "HD" + part1 + part2;

        return maHoaDon;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_dsGioHang = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btn_thanhToan = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txt_tienKhachTra = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_tongTien = new javax.swing.JTextField();
        lbl_tienThua = new javax.swing.JLabel();
        txt_tienDu = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        rb_dacothongtin = new javax.swing.JRadioButton();
        rb_vangLai = new javax.swing.JRadioButton();
        txt_sdtKH = new javax.swing.JTextField();
        btn_themMoi = new javax.swing.JButton();
        btn_timKH = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        lbl_tenKH = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_danhsachSP = new javax.swing.JTable();
        btn_themSanPham = new javax.swing.JButton();
        txt_searchKeyWord = new javax.swing.JTextField();
        btn_timKiem = new javax.swing.JButton();
        btn_prevPage = new javax.swing.JButton();
        btn_nextPage = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_hoaDonCho = new javax.swing.JTable();
        btn_suaItemGioHang = new javax.swing.JButton();
        btn_xoaItemGioHang = new javax.swing.JButton();
        btn_taohoadon = new javax.swing.JButton();

        tbl_dsGioHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Sản phẩm", "Giá", "Size", "Màu", "Chất liệu", "Số lượng", "Thành tiền", "ID HDCT", "ID SPCT"
            }
        ));
        jScrollPane1.setViewportView(tbl_dsGioHang);
        if (tbl_dsGioHang.getColumnModel().getColumnCount() > 0) {
            tbl_dsGioHang.getColumnModel().getColumn(7).setMinWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(7).setPreferredWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(7).setMaxWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(8).setMinWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(8).setPreferredWidth(0);
            tbl_dsGioHang.getColumnModel().getColumn(8).setMaxWidth(0);
        }

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_thanhToan.setText("Thanh Toán");
        btn_thanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_thanhToanActionPerformed(evt);
            }
        });

        jLabel3.setText("Thành tiền: ");

        txt_tienKhachTra.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_tienKhachTraKeyPressed(evt);
            }
        });

        jLabel4.setText("Tiền khách trả");

        txt_tongTien.setEditable(false);

        lbl_tienThua.setText("Tiền dư: ");

        txt_tienDu.setEditable(false);
        txt_tienDu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_tienDuActionPerformed(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Khách hàng");

        buttonGroup1.add(rb_dacothongtin);
        rb_dacothongtin.setText("Đã có Thông tin");

        buttonGroup1.add(rb_vangLai);
        rb_vangLai.setText("Vãng lai");

        btn_themMoi.setText("➕");
        btn_themMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themMoiActionPerformed(evt);
            }
        });

        btn_timKH.setText("🔎");
        btn_timKH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timKHActionPerformed(evt);
            }
        });

        jLabel2.setText("Tên: ");

        lbl_tenKH.setText("jLabel6");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(lbl_tenKH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(rb_dacothongtin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rb_vangLai))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(txt_sdtKH)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_timKH, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_themMoi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rb_dacothongtin)
                    .addComponent(rb_vangLai))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_sdtKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_themMoi)
                    .addComponent(btn_timKH))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lbl_tenKH))
                .addContainerGap(86, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(lbl_tienThua)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_tienDu, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_tienKhachTra, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_tongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(93, 93, 93)
                                .addComponent(btn_thanhToan)))
                        .addGap(0, 78, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_tongTien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_tienKhachTra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_tienThua, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txt_tienDu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(btn_thanhToan)
                .addGap(55, 55, 55))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách sản phẩm"));

        tbl_danhsachSP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Sản phẩm", "Màu ", "Size", "Chất liệu", "Đơn giá", "Số lượng", "ID"
            }
        ));
        jScrollPane2.setViewportView(tbl_danhsachSP);
        if (tbl_danhsachSP.getColumnModel().getColumnCount() > 0) {
            tbl_danhsachSP.getColumnModel().getColumn(6).setMinWidth(0);
            tbl_danhsachSP.getColumnModel().getColumn(6).setPreferredWidth(0);
            tbl_danhsachSP.getColumnModel().getColumn(6).setMaxWidth(0);
        }

        btn_themSanPham.setText("Thêm");
        btn_themSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themSanPhamActionPerformed(evt);
            }
        });

        btn_timKiem.setText("🔎");
        btn_timKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timKiemActionPerformed(evt);
            }
        });

        btn_prevPage.setText("<");
        btn_prevPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_prevPageActionPerformed(evt);
            }
        });

        btn_nextPage.setText(">");
        btn_nextPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nextPageActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btn_themSanPham)
                        .addGap(41, 41, 41)
                        .addComponent(txt_searchKeyWord, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_timKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_prevPage)
                        .addGap(18, 18, 18)
                        .addComponent(btn_nextPage))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_themSanPham)
                    .addComponent(txt_searchKeyWord, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_timKiem)
                    .addComponent(btn_prevPage)
                    .addComponent(btn_nextPage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tbl_hoaDonCho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID hoá đơn", "Ngày tạo ", "Trạng thái"
            }
        ));
        tbl_hoaDonCho.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_hoaDonChoMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_hoaDonCho);

        btn_suaItemGioHang.setText("Sửa");
        btn_suaItemGioHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaItemGioHangActionPerformed(evt);
            }
        });

        btn_xoaItemGioHang.setText("Xoá");
        btn_xoaItemGioHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaItemGioHangActionPerformed(evt);
            }
        });

        btn_taohoadon.setText("Tạo HĐ");
        btn_taohoadon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_taohoadonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 553, Short.MAX_VALUE)
                            .addComponent(jScrollPane1))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn_suaItemGioHang, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_xoaItemGioHang, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(btn_taohoadon, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_taohoadon))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(83, 83, 83)
                                .addComponent(btn_suaItemGioHang)
                                .addGap(18, 18, 18)
                                .addComponent(btn_xoaItemGioHang))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_taohoadonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_taohoadonActionPerformed

        LocalDate ngayTaoLocalDate = LocalDate.now();
        String maHoaDon = taoMaHoaDon();
        Date ngayTaoDate = java.sql.Date.valueOf(ngayTaoLocalDate);
        String trangThai = "Đang chờ";

        HoaDon hoaDon = new HoaDon();
        hoaDon.setNgayTao(ngayTaoDate);
        hoaDon.setMaHoaDon(maHoaDon);
        hoaDon.setTrangThai(trangThai);
        hoaDon.setIdNhanVien(idNhanVien);

        Boolean themThanhCong = hoaDonService.themHoaDon(hoaDon);
        if (themThanhCong) {
            JOptionPane.showMessageDialog(this, "Thêm hoá đơn thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);

            loadDataHoaDonCho();

        } else {
            JOptionPane.showMessageDialog(this, "Thêm hoá đơn thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);

        }
    }//GEN-LAST:event_btn_taohoadonActionPerformed

    private void tbl_hoaDonChoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_hoaDonChoMouseClicked
        loadDataGioHang();
        loadThanhTien();


    }//GEN-LAST:event_tbl_hoaDonChoMouseClicked

    private void btn_themSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themSanPhamActionPerformed
        int rowSPCT = tbl_danhsachSP.getSelectedRow();
        int rowHDC = tbl_hoaDonCho.getSelectedRow();

        if (rowSPCT == -1 || rowHDC == -1) {
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn sản phẩm hoặc hoá đơn!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idSP = tbl_danhsachSP.getValueAt(rowSPCT, 6).toString();
        Long soLuongSPCT = Long.valueOf(tbl_danhsachSP.getValueAt(rowSPCT, 5).toString());

        if (tbl_dsGioHang.getModel().getRowCount() > 0 
                && tbl_dsGioHang.getModel().getRowCount() > 0
                && IntStream.range(0, tbl_dsGioHang.getRowCount())
                        .anyMatch(i -> idSP.equals(tbl_dsGioHang.getValueAt(i, 8).toString()))) {
            JOptionPane.showMessageDialog(this, "Sản phẩm đã có trong giỏ hàng, mời chọn chức năng sửa giỏ hàng!");
            return;
        }

        String inputSoLuong = JOptionPane.showInputDialog(this, "Nhập số lượng:", "1");
        if (inputSoLuong == null || inputSoLuong.isEmpty()) {
            return;
        }

        Long soLuong = Long.valueOf(inputSoLuong);

        if (soLuong <= 0) {
            JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0!", "Thông báo!", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (soLuong > soLuongSPCT) {
            JOptionPane.showMessageDialog(this, "Số lượng trong kho không đủ!", "Thông báo!", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idHoaDon = tbl_hoaDonCho.getValueAt(rowHDC, 0).toString();
        HoaDon hoaDon = hoaDonService.getHoaDonByMaHoaDon(idHoaDon);
        Long tongTienHoaDonA = hoaDon.getTongTien();

        Long donGia = Long.valueOf(tbl_danhsachSP.getValueAt(rowSPCT, 4).toString());
        Long thanhTien = soLuong * donGia;
        Long tongTienHoaDonZ = tongTienHoaDonA + thanhTien;

        Long soLuongSauKhiThem = soLuongSPCT - soLuong;

        SanPhamChiTiet sanPhamChiTiet = sanPhamChiTietService.getSanPhamChiTietById(idSP);
        sanPhamChiTiet.setSoLuong(soLuongSauKhiThem.intValue());

        hoaDon.setTongTien(tongTienHoaDonZ);
        hoaDonService.capNhatHoaDon(hoaDon);
        sanPhamChiTietService.capNhatSanPhamChiTiet(sanPhamChiTiet);
        loadDataDSSanPham();

        HoaDonChiTiet hoaDonChiTiet = new HoaDonChiTiet();
        hoaDonChiTiet.setIdHoaDon(idHoaDon);
        hoaDonChiTiet.setIdSanPhamChiTiet(idSP);
        hoaDonChiTiet.setDonGia(donGia);
        hoaDonChiTiet.setSoLuong(soLuong.intValue());
        hoaDonChiTiet.setThanhTien(thanhTien);
        hoaDonChiTietService.themHoaDonChiTiet(hoaDonChiTiet);
        loadDataGioHang();
        loadThanhTien();
    }//GEN-LAST:event_btn_themSanPhamActionPerformed

    private void btn_xoaItemGioHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaItemGioHangActionPerformed
        //Sửa lại
        int rowSPGH = tbl_dsGioHang.getSelectedRow();
        if (rowSPGH == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một mục trong giỏ hàng để xóa.");
            return;
        }
        int confirmation = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa mục này không?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirmation != JOptionPane.YES_OPTION) {
            // Người dùng không đồng ý xóa, không thực hiện gì cả.
            return;
        }
        int row = tbl_hoaDonCho.getSelectedRow();

        String idHoaDon = tbl_hoaDonCho.getValueAt(row, 0).toString();
        HoaDon hoaDon = hoaDonService.getHoaDonByMaHoaDon(idHoaDon);
        Long tongTien = hoaDon.getTongTien();

        String idSPGHDaChon = tbl_dsGioHang.getValueAt(rowSPGH, 8).toString();
        String idHDCTDaChon = tbl_dsGioHang.getValueAt(rowSPGH, 7).toString();
        Integer soLuongSPGH = Integer.valueOf(tbl_dsGioHang.getValueAt(rowSPGH, 5).toString());
        Long thanhTien = Long.parseLong(tbl_dsGioHang.getValueAt(rowSPGH, 6).toString());
        Long truTienKhiXoa = tongTien - thanhTien;

        hoaDon.setTongTien(truTienKhiXoa);
        hoaDonService.capNhatHoaDon(hoaDon);

        SanPhamChiTiet sanPhamChiTiet = sanPhamChiTietService.getSanPhamChiTietById(idSPGHDaChon);

        boolean hoaDonChiTiet = hoaDonChiTietService.xoaHoaDonChiTiet(idHDCTDaChon);
        if (hoaDonChiTiet) {
            JOptionPane.showMessageDialog(this, "Xoá thành công!");
        }

        Integer soLuongSPCT = sanPhamChiTiet.getSoLuong();
        Integer soLuongSPCTSauKhiXoa = soLuongSPCT + soLuongSPGH;
        sanPhamChiTiet.setSoLuong(soLuongSPCTSauKhiXoa);

        sanPhamChiTietService.capNhatSanPhamChiTiet(sanPhamChiTiet);

        loadDataGioHang();
        loadDataDSSanPham();
        loadThanhTien();
    }//GEN-LAST:event_btn_xoaItemGioHangActionPerformed

    private void btn_suaItemGioHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaItemGioHangActionPerformed
        //Sửa lại
        int rowGH = tbl_dsGioHang.getSelectedRow();
        int rowHDC = tbl_hoaDonCho.getSelectedRow();

        if (rowGH == -1) {
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn sản phẩm cần sửa!", "Thông báo!", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String inputSoLuong = JOptionPane.showInputDialog(this, "Nhập số lượng:");
        if (inputSoLuong == null || inputSoLuong.isEmpty()) {
            return;
        }
        Long soLuong = Long.valueOf(inputSoLuong);

        String idSanPhamChiTiet = tbl_dsGioHang.getValueAt(rowGH, 8).toString();
        String idHoaDonChiTiet = tbl_dsGioHang.getValueAt(rowGH, 7).toString();
        Long soLuongSPGH = Long.valueOf(tbl_dsGioHang.getValueAt(rowGH, 5).toString());
        String idHoaDon = tbl_hoaDonCho.getValueAt(rowHDC, 0).toString();
        Long thanhTienBanDau = Long.valueOf(tbl_dsGioHang.getValueAt(rowGH, 6).toString());

        SanPhamChiTiet sanPhamChiTiet = sanPhamChiTietService.getSanPhamChiTietById(idSanPhamChiTiet);
        Long tongSLBanDau = sanPhamChiTiet.getSoLuong() + soLuongSPGH;
        if (soLuong <= 0) {
            JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0!", "Thông báo!", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (soLuong > tongSLBanDau) {
            JOptionPane.showMessageDialog(this, "Số lượng trong kho không đủ!", "Thông báo!", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Long tongSLDaSua = tongSLBanDau - soLuong;
        Long thanhTienDaSua = soLuong * sanPhamChiTiet.getGia();

        HoaDon hoaDon = hoaDonService.getHoaDonByMaHoaDon(idHoaDon);
        Long tongTienHDBanDau = hoaDon.getTongTien() - thanhTienBanDau;
        Long tongTienHDDaSua = tongTienHDBanDau + thanhTienDaSua;
        hoaDon.setTongTien(tongTienHDDaSua);
        hoaDonService.capNhatHoaDon(hoaDon);

        sanPhamChiTiet.setSoLuong(tongSLDaSua.intValue());
        sanPhamChiTietService.capNhatSanPhamChiTiet(sanPhamChiTiet);

        HoaDonChiTiet hoaDonChiTiet = hoaDonChiTietService.getAllHoaDonChiTietByIDHoaDonChiTiet(idHoaDonChiTiet);
        hoaDonChiTiet.setSoLuong(soLuong.intValue());
        hoaDonChiTiet.setThanhTien(thanhTienDaSua);
        hoaDonChiTietService.updateHoaDonChiTietByIdHoaDonChiTiet(hoaDonChiTiet);

        loadDataGioHang();
        loadDataDSSanPham();
        loadThanhTien();

    }//GEN-LAST:event_btn_suaItemGioHangActionPerformed

    private void btn_timKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timKHActionPerformed
        String sdtKH = txt_sdtKH.getText();
        KhachHang khachHang = khachHangService.getKhachHangBySdt(sdtKH);
        if (khachHang != null) {
            JOptionPane.showMessageDialog(this, "Đã tìm thấy thông tin khách hàng với SĐT: " + sdtKH);
            lbl_tenKH.setText(khachHang.getTenKhachHang());
        } else {
            lbl_tenKH.setText("Trống!");
            JOptionPane.showMessageDialog(this, "Chưa có thông tin khách hàng với SĐT: " + sdtKH);
        }

    }//GEN-LAST:event_btn_timKHActionPerformed

    private void btn_themMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themMoiActionPerformed
        Form_ThemNhanhKhachHang form_ThemNhanhKhachHang = new Form_ThemNhanhKhachHang();
        form_ThemNhanhKhachHang.setVisible(true);
    }//GEN-LAST:event_btn_themMoiActionPerformed

    private void txt_tienDuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_tienDuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_tienDuActionPerformed

    private void txt_tienKhachTraKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_tienKhachTraKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            int row = tbl_hoaDonCho.getSelectedRow();
            if (row != -1) {
                String idHoaDon = tbl_hoaDonCho.getValueAt(row, 0).toString();
                HoaDon hoaDon = hoaDonService.getHoaDonByMaHoaDon(idHoaDon);
                Long tongTien = Long.valueOf(txt_tongTien.getText());

                try {
                    Long tienKhachTra = Long.parseLong(txt_tienKhachTra.getText());
                    Long tienDu = tienKhachTra - tongTien;

                    if (tienDu < 0) {
                        // Nếu tienDu là âm, thì sửa giá trị và hiển thị màu đỏ
                        lbl_tienThua.setForeground(Color.RED);
                        lbl_tienThua.setText("Còn Thiếu: ");
                        tienDu = Math.abs(tienDu);
                    } else {
                        // Nếu không âm, sửa màu về mặc định và hiển thị giá trị
                        lbl_tienThua.setForeground(lbl_tienThua.getForeground());
                        lbl_tienThua.setText("Trả lại khách :");
                    }

                    txt_tienDu.setText(String.valueOf(tienDu));
                } catch (NumberFormatException e) {
                    // Xử lý nếu người dùng nhập không phải là số
                    JOptionPane.showMessageDialog(null, "Vui lòng nhập số nguyên");
                    // Có thể thêm code xử lý khác tùy vào yêu cầu của bạn
                }
            } else {
                // Xử lý nếu không có hàng được chọn trong bảng
                JOptionPane.showMessageDialog(null, "Vui lòng chọn một hóa đơn trong bảng");
                // Có thể thêm code xử lý khác tùy vào yêu cầu của bạn
            }
        }
    }//GEN-LAST:event_txt_tienKhachTraKeyPressed

    private void btn_thanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_thanhToanActionPerformed

        // Early exit for common validation errors
        if (tbl_hoaDonCho.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(this, "Chưa chọn hóa đơn cần thanh toán!");
            return;
        }
        if (txt_tienKhachTra.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chưa nhập tiền khách trả!");
            return;
        }
        long tienDu = Long.parseLong(txt_tienDu.getText());
        if (lbl_tienThua.getText().contains("Còn Thiếu")) {
            JOptionPane.showMessageDialog(this, "Khách hàng còn thiếu: " + Math.abs(tienDu) + " VNĐ");
            return;
        }

        String idHoaDon = tbl_hoaDonCho.getValueAt(tbl_hoaDonCho.getSelectedRow(), 0).toString();
        HoaDon hoaDon = hoaDonService.getHoaDonByMaHoaDon(idHoaDon);

        // Set trạng thái to "Đã thanh toán" unconditionally
        hoaDon.setTrangThai("Đã thanh toán");
        String tongTienText = txt_tongTien.getText(); // Lấy giá trị từ JTextField
        long tongTien = Long.parseLong(tongTienText); // Chuyển đổi giá trị thành kiểu long
        hoaDon.setTongTien(tongTien); // Gán giá trị cho thuộc tính tongTien của đối tượng hoaDon

        // Handle customer information conditionally
        if (rb_dacothongtin.isSelected()) {
            String sdtKH = txt_sdtKH.getText();
            if (sdtKH.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Thiếu thông tin khách hàng!");
                return;
            }

            KhachHang khachHang = khachHangService.getKhachHangBySdt(sdtKH);
            if (lbl_tenKH.getText().equalsIgnoreCase("Trống!")) {
                JOptionPane.showMessageDialog(this, "Khách hàng trống với SĐT hiện tại!");
                return;
            }

            hoaDon.setIdKhachHang(khachHang.getIdKhachHang());
        }

        // Confirmation dialog
        if (JOptionPane.showConfirmDialog(
                this,
                "Xác nhận thanh toán?",
                "Xác nhận",
                JOptionPane.YES_NO_OPTION
        ) == JOptionPane.YES_OPTION) {

            boolean thanhToanThanhCong = hoaDonService.capNhatHoaDon(hoaDon);
            if (thanhToanThanhCong) {
                JOptionPane.showMessageDialog(this, "Thanh toán thành công!");
                loadDataHoaDonCho();
                ((DefaultTableModel) tbl_dsGioHang.getModel()).setRowCount(0);
                txt_tongTien.setText("");
                txt_tienKhachTra.setText("");
                txt_tienDu.setText("");
            }
        }
    }//GEN-LAST:event_btn_thanhToanActionPerformed

    private void btn_timKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timKiemActionPerformed
        String keyWord = txt_searchKeyWord.getText();

        List<SanPhamChiTiet> listSanPhamChiTiets = sanPhamChiTietService.getAllSanPhamChiTietViewTableSearch(keyWord);

        defaultTableModel = (DefaultTableModel) tbl_danhsachSP.getModel();
        defaultTableModel.setRowCount(0);

        listSanPhamChiTiets.forEach(sanPhamChiTiet -> {
            defaultTableModel.addRow(new Object[]{
                sanPhamChiTiet.getTenSanPham(),
                sanPhamChiTiet.getTenMauSac(),
                sanPhamChiTiet.getSize(),
                sanPhamChiTiet.getTenChatLieu(),
                sanPhamChiTiet.getGia(),
                sanPhamChiTiet.getSoLuong(),
                sanPhamChiTiet.getIdSanPhamChiTiet(),});
        });
    }//GEN-LAST:event_btn_timKiemActionPerformed

    private void btn_prevPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_prevPageActionPerformed
        currentPage--;
        loadDataDSSanPham();
        prev();
        next();
    }//GEN-LAST:event_btn_prevPageActionPerformed

    private void btn_nextPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nextPageActionPerformed
        currentPage++;
        loadDataDSSanPham();
        prev();
        next();
    }//GEN-LAST:event_btn_nextPageActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_nextPage;
    private javax.swing.JButton btn_prevPage;
    private javax.swing.JButton btn_suaItemGioHang;
    private javax.swing.JButton btn_taohoadon;
    private javax.swing.JButton btn_thanhToan;
    private javax.swing.JButton btn_themMoi;
    private javax.swing.JButton btn_themSanPham;
    private javax.swing.JButton btn_timKH;
    private javax.swing.JButton btn_timKiem;
    private javax.swing.JButton btn_xoaItemGioHang;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lbl_tenKH;
    private javax.swing.JLabel lbl_tienThua;
    private javax.swing.JRadioButton rb_dacothongtin;
    private javax.swing.JRadioButton rb_vangLai;
    private javax.swing.JTable tbl_danhsachSP;
    private javax.swing.JTable tbl_dsGioHang;
    private javax.swing.JTable tbl_hoaDonCho;
    private javax.swing.JTextField txt_sdtKH;
    private javax.swing.JTextField txt_searchKeyWord;
    private javax.swing.JTextField txt_tienDu;
    private javax.swing.JTextField txt_tienKhachTra;
    private javax.swing.JTextField txt_tongTien;
    // End of variables declaration//GEN-END:variables
}
