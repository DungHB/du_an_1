package com.raven.form;

import com.asm.polybee.model.ChatLieu;
import com.asm.polybee.model.MauSac;
import com.asm.polybee.model.SanPham;
import com.asm.polybee.model.SanPhamChiTiet;
import com.asm.polybee.model.Size;
import com.asm.polybee.model.TheLoai;
import com.asm.polybee.model.ThuongHieu;
import com.asm.polybee.service.ChatLieuService;
import com.asm.polybee.service.Impl.ChatLieuServiceImpl;
import com.asm.polybee.service.Impl.MauSacServiceImpl;
import com.asm.polybee.service.Impl.SanPhamChiTietServiceImpl;
import com.asm.polybee.service.Impl.SanPhamServiceImpl;
import com.asm.polybee.service.Impl.SizeServiceImpl;
import com.asm.polybee.service.Impl.TheLoaiServiceImpl;
import com.asm.polybee.service.Impl.ThuongHieuServiceImpl;
import com.asm.polybee.service.MauSacService;
import com.asm.polybee.service.SanPhamChiTietService;
import com.asm.polybee.service.SanPhamService;
import com.asm.polybee.service.SizeService;
import com.asm.polybee.service.TheLoaiService;
import com.asm.polybee.service.ThuongHieuService;
import java.util.List;
import java.util.Optional;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Form_2 extends javax.swing.JPanel {

    DefaultTableModel defaultTableModel;

    private SanPhamService sanPhamService = new SanPhamServiceImpl();
    private SanPhamChiTietService sanPhamChiTietService = new SanPhamChiTietServiceImpl();
    private SizeService sizeService = new SizeServiceImpl();
    private ChatLieuService chatLieuService = new ChatLieuServiceImpl();
    private MauSacService mauSacService = new MauSacServiceImpl();
    private TheLoaiService theLoaiService = new TheLoaiServiceImpl();
    private ThuongHieuService thuongHieuService = new ThuongHieuServiceImpl();
    List<TheLoai> listTheLoais = theLoaiService.getAll();
    List<ThuongHieu> listThuongHieus = thuongHieuService.getAll();

    ;
    List<SanPham> listSanPham = sanPhamService.getAll();

    List<Size> listSizes = sizeService.getAll();
    List<ChatLieu> listChatLieus = chatLieuService.getAll();
    List<MauSac> listMauSacs = mauSacService.getAll();

    private int currentPage = 1;
    private int pageSize = 3;

    private int currentPageSPCT = 1;
    private int pageSizeSPCT = 3;

    /**
     * Creates new form Form_1
     */
    public Form_2() {
        initComponents();
        comboBoxLoadData();
        loadDataSanPham();
        loadDataSanPhamChiTiet();
        jLabel3.setText(String.valueOf(currentPage));
        prev();
        next();
        prevSPCT();
        int countSP = sanPhamService.getCountSanPham();
        int maxSize = countSP / pageSize;
        int remainder = countSP % pageSize;
        if (remainder > 0) {
            maxSize++;
        }
    }

    void loadDataSanPham() {
        List<SanPham> listSanPhamPaging = sanPhamService.getSanPhamsByPage((currentPage - 1) * pageSize, pageSize);

        defaultTableModel = (DefaultTableModel) tbl_sanPham.getModel();
        defaultTableModel.setRowCount(0);

        for (SanPham sanPham : listSanPhamPaging) {

            defaultTableModel.addRow(new Object[]{
                sanPham.getIdSanPham(),
                sanPham.getMaSanPham(),
                sanPham.getTenSanPham(),
                sanPham.getIdTheLoai(),
                sanPham.getIdThuongHieu(),
                sanPham.getTrangThai()
            });

        }
    }

    void clearSP() {
        txt_maSanPham.setText("");
        txt_tenSanPham.setText("");
        cbb_theLoai.setSelectedIndex(0);
        cbb_thuongHieu.setSelectedIndex(0);

    }

    void loadDataSanPhamChiTiet() {
        List<SanPhamChiTiet> listSanPhamChiTiet = sanPhamChiTietService.getAllSanPhamChiTietViewTable((currentPageSPCT - 1) * pageSizeSPCT, pageSizeSPCT);
        defaultTableModel = (DefaultTableModel) tbl_sanPhamChiTiet.getModel();
        defaultTableModel.setRowCount(0);

        for (SanPhamChiTiet sanPhamChiTiet : listSanPhamChiTiet) {

            defaultTableModel.addRow(new Object[]{
                sanPhamChiTiet.getTenSanPham(),
                sanPhamChiTiet.getTenChatLieu(),
                sanPhamChiTiet.getTenMauSac(),
                sanPhamChiTiet.getSize(),
                sanPhamChiTiet.getGia(),
                sanPhamChiTiet.getSoLuong(),
                sanPhamChiTiet.getIdSanPhamChiTiet()
            });

        }
    }

    void prev() {
        if (this.currentPage <= 1) {
            this.btn_prevPage.setEnabled(false);
        } else {
            this.btn_prevPage.setEnabled(true);
        }
    }

    void next() {
        int countSPCT = sanPhamService.getCountSanPham();
        int maxSize = countSPCT / pageSize;
        int remainder = countSPCT % pageSize;
        if (remainder > 0) {
            maxSize++;
        }

        if (currentPage >= maxSize) {

            btn_nextPage.setEnabled(false);

        } else {
            btn_nextPage.setEnabled(true);
        }
    }

    void prevSPCT() {
        if (this.currentPageSPCT <= 1) {
            this.btn_prevPageSPCT.setEnabled(false);
        } else {
            this.btn_prevPageSPCT.setEnabled(true);
        }
    }

    void nextSPCT() {
        int countSP = sanPhamChiTietService.getCountSPCT();
        int maxSize = countSP / pageSize;
        int remainder = countSP % pageSize;
        if (remainder > 0) {
            maxSize++;
        }

        if (currentPageSPCT >= maxSize) {

            btn_nextPageSPCT.setEnabled(false);

        } else {
            btn_nextPageSPCT.setEnabled(true);
        }
    }

    void comboBoxLoadData() {
        DefaultComboBoxModel<String> modelSanPham = new DefaultComboBoxModel<>();
        for (SanPham sanPham : listSanPham) {
            modelSanPham.addElement((String) String.valueOf(sanPham.getTenSanPham()));
        }
        cbb_tenSanPham.setModel(modelSanPham);

        DefaultComboBoxModel<String> modelSize = new DefaultComboBoxModel<>();
        for (Size size : listSizes) {
            modelSize.addElement((String) String.valueOf(size.getSize()));
        }
        cbb_size.setModel(modelSize);

        DefaultComboBoxModel<String> modelChatLieu = new DefaultComboBoxModel<>();
        for (ChatLieu chatLieu : listChatLieus) {
            modelChatLieu.addElement((String) String.valueOf(chatLieu.getTenChatLieu()));
        }
        cbb_chatLieu.setModel(modelChatLieu);

        DefaultComboBoxModel<String> modelMauSac = new DefaultComboBoxModel<>();
        for (MauSac mauSac : listMauSacs) {
            modelMauSac.addElement((String) String.valueOf(mauSac.getTenMauSac()));
        }
        cbb_mauSac.setModel(modelMauSac);

        DefaultComboBoxModel<String> modelTheLoai = new DefaultComboBoxModel<>();
        for (TheLoai theLoai : listTheLoais) {
            modelTheLoai.addElement(theLoai.getTenTheLoai());
        }
        cbb_theLoai.setModel(modelTheLoai);

        // Thêm tên thương hiệu vào model
        DefaultComboBoxModel<String> modelThuongHieu = new DefaultComboBoxModel<>();
        for (ThuongHieu thuongHieu : listThuongHieus) {
            modelThuongHieu.addElement(thuongHieu.getTenThuongHieu());
        }
        cbb_thuongHieu.setModel(modelThuongHieu);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txt_maSanPham = new javax.swing.JTextField();
        txt_tenSanPham = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        cbb_theLoai = new javax.swing.JComboBox<>();
        cbb_thuongHieu = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        rb_hoatDong = new javax.swing.JRadioButton();
        rb_khongHoatDong = new javax.swing.JRadioButton();
        jPanel6 = new javax.swing.JPanel();
        btn_them = new javax.swing.JButton();
        btn_suaSanPham = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_sanPham = new javax.swing.JTable();
        btn_prevPage = new javax.swing.JButton();
        btn_nextPage = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btn_timSP = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txt_keyWordSP = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        btn_themSPCT = new javax.swing.JButton();
        btn_suaSPCT = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        cbb_tenSanPham = new javax.swing.JComboBox<>();
        txt_soLuongTon = new javax.swing.JTextField();
        txt_gia = new javax.swing.JTextField();
        cbb_size = new javax.swing.JComboBox<>();
        cbb_mauSac = new javax.swing.JComboBox<>();
        cbb_chatLieu = new javax.swing.JComboBox<>();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_sanPhamChiTiet = new javax.swing.JTable();
        btn_prevPageSPCT = new javax.swing.JButton();
        btn_nextPageSPCT = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txt_keyWord = new javax.swing.JTextField();
        btn_timKiem = new javax.swing.JButton();

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin sản phẩm")));

        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setText("Tên sản phẩm");

        jLabel1.setText("Mã sản phẩm");

        jLabel29.setText("Thể Loại");

        jLabel30.setText("Thương Hiệu");

        cbb_theLoai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbb_thuongHieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel9.setText("Trạng thái");

        buttonGroup1.add(rb_hoatDong);
        rb_hoatDong.setText("Hoạt động");

        buttonGroup1.add(rb_khongHoatDong);
        rb_khongHoatDong.setText("Không hoạt động");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txt_maSanPham, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                    .addComponent(txt_tenSanPham))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbb_thuongHieu, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addGap(18, 18, 18)
                        .addComponent(cbb_theLoai, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rb_hoatDong)
                            .addComponent(rb_khongHoatDong)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(txt_maSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel29)
                        .addComponent(cbb_theLoai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rb_hoatDong)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_tenSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30)
                    .addComponent(cbb_thuongHieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rb_khongHoatDong))
                .addGap(22, 22, 22))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_them.setText("Thêm");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_suaSanPham.setText("Sửa");
        btn_suaSanPham.setPreferredSize(new java.awt.Dimension(77, 22));
        btn_suaSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaSanPhamActionPerformed(evt);
            }
        });

        jButton3.setText("Làm mới");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton3)
                    .addComponent(btn_suaSanPham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_them, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(btn_them)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_suaSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Danh sách sản phẩm"));

        tbl_sanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Mã SP", "Tên SP", "Thể loại", "Thương hiệu", "Trạng thái"
            }
        ));
        tbl_sanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_sanPhamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_sanPham);

        btn_prevPage.setText("<");
        btn_prevPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_prevPageActionPerformed(evt);
            }
        });

        btn_nextPage.setText(">");
        btn_nextPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nextPageActionPerformed(evt);
            }
        });

        jLabel3.setText("jLabel3");

        btn_timSP.setText("Tìm");
        btn_timSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timSPActionPerformed(evt);
            }
        });

        jLabel11.setText("Tìm kiếm");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 955, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(btn_prevPage)
                                .addGap(33, 33, 33)
                                .addComponent(jLabel3)
                                .addGap(27, 27, 27)
                                .addComponent(btn_nextPage))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(18, 18, 18)
                                .addComponent(txt_keyWordSP, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_timSP)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_timSP)
                    .addComponent(jLabel11)
                    .addComponent(txt_keyWordSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_prevPage)
                    .addComponent(btn_nextPage)
                    .addComponent(jLabel3))
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Sản phẩm", jPanel1);

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Thông tin sản phẩm")));

        jLabel4.setText("Tên sản phẩm");

        jLabel5.setText("Số lượng tồn");

        jLabel6.setText("Giá");

        jLabel7.setText("Size");

        jLabel8.setText("Màu sắc");

        jPanel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_themSPCT.setText("Thêm mới");
        btn_themSPCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themSPCTActionPerformed(evt);
            }
        });

        btn_suaSPCT.setText("Sửa");
        btn_suaSPCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaSPCTActionPerformed(evt);
            }
        });

        jButton8.setText("Thuộc tính");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_suaSPCT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_themSPCT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(16, 16, 16))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(btn_themSPCT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_suaSPCT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton8)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jLabel10.setText("Chất liệu");

        cbb_tenSanPham.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbb_size.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbb_mauSac.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbb_chatLieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbb_tenSanPham, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_soLuongTon)
                            .addComponent(txt_gia, javax.swing.GroupLayout.DEFAULT_SIZE, 445, Short.MAX_VALUE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel7))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbb_chatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbb_mauSac, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbb_size, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbb_tenSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(cbb_chatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_soLuongTon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(cbb_mauSac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txt_gia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbb_size, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Danh sách sản phẩm"));

        tbl_sanPhamChiTiet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Sản phẩm", "Chất liệu", "Màu sắc", "Size", "Giá", "Số lượng", "ID"
            }
        ));
        tbl_sanPhamChiTiet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_sanPhamChiTietMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_sanPhamChiTiet);

        btn_prevPageSPCT.setText("<");
        btn_prevPageSPCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_prevPageSPCTActionPerformed(evt);
            }
        });

        btn_nextPageSPCT.setText(">");
        btn_nextPageSPCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nextPageSPCTActionPerformed(evt);
            }
        });

        jLabel12.setText("Tìm kiếm");

        btn_timKiem.setText("Tìm");
        btn_timKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(283, 283, 283)
                        .addComponent(btn_prevPageSPCT, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(128, 128, 128)
                        .addComponent(btn_nextPageSPCT, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 684, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(txt_keyWord, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_timKiem)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txt_keyWord, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_timKiem))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_prevPageSPCT)
                    .addComponent(btn_nextPageSPCT))
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Chi tiết sản phẩm", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        String maSanPham = txt_maSanPham.getText();
        String tenSanPham = txt_tenSanPham.getText();
        String tenTheLoaiDuocChon = (String) cbb_theLoai.getSelectedItem();
        String tenThuongHieuDuocChon = (String) cbb_thuongHieu.getSelectedItem();
        String trangThai = null;

        if (rb_hoatDong.isSelected()) {
            trangThai = "Hoạt động";
        } else {
            trangThai = "Không hoạt động";
        }

        // Sử dụng Java Streams để tìm đối tượng TheLoai tương ứng với tên được chọn
        Optional<TheLoai> optionalTheLoai = listTheLoais.stream()
                .filter(tl -> tl.getTenTheLoai().equals(tenTheLoaiDuocChon))
                .findFirst();

        Optional<ThuongHieu> optionalThuongHieu = listThuongHieus.stream()
                .filter(th -> th.getTenThuongHieu().equals(tenThuongHieuDuocChon))
                .findFirst();

        String idThuongHieuDuocChon = optionalThuongHieu.map(ThuongHieu::getIdThuongHieu).orElse(null);
        String idTheLoaiDuocChon = optionalTheLoai.map(TheLoai::getIdTheloai).orElse(null);

        SanPham sanPhamCheckTrung = sanPhamService.layThongTinSanPhamTheoMa(maSanPham);
        if (sanPhamCheckTrung != null) {
            JOptionPane.showMessageDialog(this, "Trùng mã sản phẩm!");
            return;
        }

        SanPham sanPham = new SanPham();
        sanPham.setMaSanPham(maSanPham);
        sanPham.setTenSanPham(tenSanPham);
        sanPham.setIdTheLoai(idTheLoaiDuocChon);
        sanPham.setIdThuongHieu(idThuongHieuDuocChon);
        sanPham.setTrangThai(trangThai);

        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có muốn thêm sản phẩm?", "Xác nhận", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean isThemThanhCong = sanPhamService.themSanPham(sanPham);

            if (isThemThanhCong) {
                JOptionPane.showMessageDialog(this, "Thêm sản phẩm thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                clearSP();
                loadDataSanPham();
            } else {
                JOptionPane.showMessageDialog(this, "Thêm sản phẩm thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }

    }//GEN-LAST:event_btn_themActionPerformed

    private void btn_suaSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaSanPhamActionPerformed
        int row = tbl_sanPham.getSelectedRow();

        String maSanPham = txt_maSanPham.getText();
        String tenSanPham = txt_tenSanPham.getText();

        String tenTheLoaiDuocChon = (String) cbb_theLoai.getSelectedItem();
        String tenThuongHieuDuocChon = (String) cbb_thuongHieu.getSelectedItem();

        String trangThai = null;

        if (rb_hoatDong.isSelected()) {
            trangThai = "Hoạt động";
        } else {
            trangThai = "Không hoạt động";
        }
        // Sử dụng Java Streams để tìm đối tượng TheLoai tương ứng với tên được chọn
        Optional<TheLoai> optionalTheLoai = listTheLoais.stream()
                .filter(tl -> tl.getTenTheLoai().equals(tenTheLoaiDuocChon))
                .findFirst();

        Optional<ThuongHieu> optionalThuongHieu = listThuongHieus.stream()
                .filter(th -> th.getTenThuongHieu().equals(tenThuongHieuDuocChon))
                .findFirst();

        String idThuongHieuDuocChon = optionalThuongHieu.map(ThuongHieu::getIdThuongHieu).orElse(null);
        String idTheLoaiDuocChon = optionalTheLoai.map(TheLoai::getIdTheloai).orElse(null);

        if (row != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Bạn có muốn cập nhật sản phẩm?", "Xác nhận", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                String idSanPham = tbl_sanPham.getValueAt(row, 0).toString();

                SanPham sanPham = sanPhamService.layThongTinSanPhamTheoId(idSanPham);

                sanPham.setMaSanPham(maSanPham);
                sanPham.setTenSanPham(tenSanPham);
                sanPham.setIdTheLoai(idTheLoaiDuocChon);
                sanPham.setIdThuongHieu(idThuongHieuDuocChon);
                sanPham.setTrangThai(trangThai);

                if (sanPham != null) {
                    sanPhamService.capNhatSanPham(sanPham);
                    JOptionPane.showMessageDialog(this, "Cập nhật sản phẩm thành công!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                    loadDataSanPham();
                    clearSP();
                } else {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin sản phẩm.", "Thông báo", JOptionPane.WARNING_MESSAGE);
                }
            }
        } else {
            // Thông báo khi không có hàng được chọn
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một sản phẩm để sửa.", "Thông báo", JOptionPane.WARNING_MESSAGE);
        }

    }//GEN-LAST:event_btn_suaSanPhamActionPerformed

    private void btn_prevPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_prevPageActionPerformed
        this.currentPage--;
        prev();
        loadDataSanPham();
        jLabel3.setText(String.valueOf(currentPage));
        next();
    }//GEN-LAST:event_btn_prevPageActionPerformed

    private void btn_nextPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nextPageActionPerformed
        currentPage++;
        jLabel3.setText(String.valueOf(currentPage));
        loadDataSanPham();
        prev();
        next();
    }//GEN-LAST:event_btn_nextPageActionPerformed

    private void btn_themSPCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themSPCTActionPerformed
        String soLuongTon = txt_soLuongTon.getText();
        String gia = txt_gia.getText();
        String tenSanPhamDuocChon = (String) cbb_tenSanPham.getSelectedItem();
        String tenSizeDuocChon = (String) cbb_size.getSelectedItem();
        String tenChatLieuDuocChon = (String) cbb_chatLieu.getSelectedItem();
        String tenMauSacDuocChon = (String) cbb_mauSac.getSelectedItem();

        //Dùng Streams để lấy ID thay vì tên
        Optional<SanPham> optionalSanPham = listSanPham.stream()
                .filter(sp -> sp.getTenSanPham().equals(tenSanPhamDuocChon))
                .findFirst();

        Optional<Size> optionalSize = listSizes.stream()
                .filter(sz -> sz.getSize().equals(tenSizeDuocChon))
                .findFirst();

        Optional<ChatLieu> optionalChatLieu = listChatLieus.stream()
                .filter(cl -> cl.getTenChatLieu().equals(tenChatLieuDuocChon))
                .findFirst();

        Optional<MauSac> optionalMauSac = listMauSacs.stream()
                .filter(ms -> ms.getTenMauSac().equals(tenMauSacDuocChon))
                .findFirst();

        String idSanPhamDaChon = optionalSanPham.map(SanPham::getIdSanPham).orElse(null);
        String idSizeDaChon = optionalSize.map(Size::getIdSize).orElse(null);
        String idChatLieuDaChon = optionalChatLieu.map(ChatLieu::getIdChatLieu).orElse(null);
        String idMauSacDaChon = optionalMauSac.map(MauSac::getIdMauSac).orElse(null);

        SanPhamChiTiet sanPhamChiTiet = new SanPhamChiTiet();
        sanPhamChiTiet.setIdSanPham(idSanPhamDaChon);
        sanPhamChiTiet.setGia(Long.valueOf(gia));
        sanPhamChiTiet.setSoLuong(Integer.valueOf(soLuongTon));
        sanPhamChiTiet.setIdSize(idSizeDaChon);
        sanPhamChiTiet.setIdChatLieu(idChatLieuDaChon);
        sanPhamChiTiet.setIdMauSac(idMauSacDaChon);

        boolean isThemThanhCong = sanPhamChiTietService.themSanPhamChiTiet(sanPhamChiTiet);
        if (isThemThanhCong) {
            JOptionPane.showMessageDialog(this, "Thêm sản phẩm chi tiết thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            txt_gia.setText("");
            txt_soLuongTon.setText("");
            cbb_size.setSelectedIndex(0);
            cbb_chatLieu.setSelectedIndex(0);
            cbb_tenSanPham.setSelectedIndex(0);
            cbb_mauSac.setSelectedIndex(0);
            loadDataSanPhamChiTiet();

        } else {
            JOptionPane.showMessageDialog(this, "Thêm sản phẩm thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btn_themSPCTActionPerformed

    private void btn_suaSPCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaSPCTActionPerformed
        int row = tbl_sanPhamChiTiet.getSelectedRow();

        String idSPCT = tbl_sanPhamChiTiet.getValueAt(row, 6).toString();
        String soLuongTon = txt_soLuongTon.getText();
        String gia = txt_gia.getText();
        String tenSanPhamDuocChon = (String) cbb_tenSanPham.getSelectedItem();
        String tenSizeDuocChon = (String) cbb_size.getSelectedItem();
        String tenChatLieuDuocChon = (String) cbb_chatLieu.getSelectedItem();
        String tenMauSacDuocChon = (String) cbb_mauSac.getSelectedItem();

        //Dùng Streams để lấy ID thay vì tên
        Optional<SanPham> optionalSanPham = listSanPham.stream()
                .filter(sp -> sp.getTenSanPham().equals(tenSanPhamDuocChon))
                .findFirst();

        Optional<Size> optionalSize = listSizes.stream()
                .filter(sz -> sz.getSize().equals(tenSizeDuocChon))
                .findFirst();

        Optional<ChatLieu> optionalChatLieu = listChatLieus.stream()
                .filter(cl -> cl.getTenChatLieu().equals(tenChatLieuDuocChon))
                .findFirst();

        Optional<MauSac> optionalMauSac = listMauSacs.stream()
                .filter(ms -> ms.getTenMauSac().equals(tenMauSacDuocChon))
                .findFirst();

        String idSanPhamDaChon = optionalSanPham.map(SanPham::getIdSanPham).orElse(null);
        String idSizeDaChon = optionalSize.map(Size::getIdSize).orElse(null);
        String idChatLieuDaChon = optionalChatLieu.map(ChatLieu::getIdChatLieu).orElse(null);
        String idMauSacDaChon = optionalMauSac.map(MauSac::getIdMauSac).orElse(null);

        SanPhamChiTiet sanPhamChiTiet = sanPhamChiTietService.getSanPhamChiTietById(idSPCT);
        sanPhamChiTiet.setIdSanPham(idSanPhamDaChon);
        sanPhamChiTiet.setGia(Long.valueOf(gia));
        sanPhamChiTiet.setSoLuong(Integer.valueOf(soLuongTon));
        sanPhamChiTiet.setIdSize(idSizeDaChon);
        sanPhamChiTiet.setIdChatLieu(idChatLieuDaChon);
        sanPhamChiTiet.setIdMauSac(idMauSacDaChon);

        boolean isThemThanhCong = sanPhamChiTietService.capNhatSanPhamChiTiet(sanPhamChiTiet);
        if (isThemThanhCong) {
            JOptionPane.showMessageDialog(this, "Update sản phẩm chi tiết thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            txt_gia.setText("");
            txt_soLuongTon.setText("");
            cbb_size.setSelectedIndex(0);
            cbb_chatLieu.setSelectedIndex(0);
            cbb_tenSanPham.setSelectedIndex(0);
            cbb_mauSac.setSelectedIndex(0);
            loadDataSanPhamChiTiet();

        } else {
            JOptionPane.showMessageDialog(this, "Thêm sản phẩm thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btn_suaSPCTActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
//        QuanLyThuocTinh quanLyThuocTinh = new QuanLyThuocTinh();
//        quanLyThuocTinh.setVisible(true);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void tbl_sanPhamChiTietMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_sanPhamChiTietMouseClicked
        int row = tbl_sanPhamChiTiet.getSelectedRow();

        txt_gia.setText(tbl_sanPhamChiTiet.getValueAt(row, 4).toString());
        txt_soLuongTon.setText(tbl_sanPhamChiTiet.getValueAt(row, 5).toString());
        cbb_size.setSelectedItem(tbl_sanPhamChiTiet.getValueAt(row, 3).toString());
        cbb_chatLieu.setSelectedItem(tbl_sanPhamChiTiet.getValueAt(row, 1).toString());
        cbb_tenSanPham.setSelectedItem(tbl_sanPhamChiTiet.getValueAt(row, 0).toString());
        cbb_mauSac.setSelectedItem(tbl_sanPhamChiTiet.getValueAt(row, 2).toString());
    }//GEN-LAST:event_tbl_sanPhamChiTietMouseClicked

    private void tbl_sanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_sanPhamMouseClicked
        int row = tbl_sanPham.getSelectedRow();

        txt_maSanPham.setText(tbl_sanPham.getValueAt(row, 1).toString());
        txt_tenSanPham.setText(tbl_sanPham.getValueAt(row, 2).toString());
        cbb_theLoai.setSelectedItem(tbl_sanPham.getValueAt(row, 3).toString());
        cbb_thuongHieu.setSelectedItem(tbl_sanPham.getValueAt(row, 4).toString());

        if (tbl_sanPham.getValueAt(row, 5).toString().equalsIgnoreCase("Hoạt động")) {
            rb_hoatDong.setSelected(true);
        } else {
            rb_khongHoatDong.setSelected(true);
        }
    }//GEN-LAST:event_tbl_sanPhamMouseClicked

    private void btn_prevPageSPCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_prevPageSPCTActionPerformed
        currentPageSPCT--;
        loadDataSanPhamChiTiet();
        prevSPCT();
        nextSPCT();
    }//GEN-LAST:event_btn_prevPageSPCTActionPerformed

    private void btn_nextPageSPCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nextPageSPCTActionPerformed
        currentPageSPCT++;
        loadDataSanPhamChiTiet();
        prevSPCT();
        nextSPCT();
    }//GEN-LAST:event_btn_nextPageSPCTActionPerformed

    private void btn_timSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timSPActionPerformed

        List<SanPham> sanPhams = sanPhamService.getSearchSP(txt_keyWordSP.getText());

        defaultTableModel = (DefaultTableModel) tbl_sanPham.getModel();
        defaultTableModel.setRowCount(0);

        for (SanPham sanPham : sanPhams) {

            defaultTableModel.addRow(new Object[]{
                sanPham.getIdSanPham(),
                sanPham.getMaSanPham(),
                sanPham.getTenSanPham(),
                sanPham.getIdTheLoai(),
                sanPham.getIdThuongHieu(),
                sanPham.getTrangThai()
            });

        }
    }//GEN-LAST:event_btn_timSPActionPerformed

    private void btn_timKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timKiemActionPerformed
        List<SanPhamChiTiet> sanPhamChiTiets = sanPhamChiTietService.getAllSanPhamChiTietViewTableSearch(txt_keyWord.getText());

        defaultTableModel = (DefaultTableModel) tbl_sanPhamChiTiet.getModel();
        defaultTableModel.setRowCount(0);

        for (SanPhamChiTiet sanPhamChiTiet : sanPhamChiTiets) {

            defaultTableModel.addRow(new Object[]{
                sanPhamChiTiet.getTenSanPham(),
                sanPhamChiTiet.getTenChatLieu(),
                sanPhamChiTiet.getTenMauSac(),
                sanPhamChiTiet.getSize(),
                sanPhamChiTiet.getGia(),
                sanPhamChiTiet.getSoLuong(),
                sanPhamChiTiet.getIdSanPhamChiTiet()
            });

        }

    }//GEN-LAST:event_btn_timKiemActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_nextPage;
    private javax.swing.JButton btn_nextPageSPCT;
    private javax.swing.JButton btn_prevPage;
    private javax.swing.JButton btn_prevPageSPCT;
    private javax.swing.JButton btn_suaSPCT;
    private javax.swing.JButton btn_suaSanPham;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_themSPCT;
    private javax.swing.JButton btn_timKiem;
    private javax.swing.JButton btn_timSP;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbb_chatLieu;
    private javax.swing.JComboBox<String> cbb_mauSac;
    private javax.swing.JComboBox<String> cbb_size;
    private javax.swing.JComboBox<String> cbb_tenSanPham;
    private javax.swing.JComboBox<String> cbb_theLoai;
    private javax.swing.JComboBox<String> cbb_thuongHieu;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton rb_hoatDong;
    private javax.swing.JRadioButton rb_khongHoatDong;
    private javax.swing.JTable tbl_sanPham;
    private javax.swing.JTable tbl_sanPhamChiTiet;
    private javax.swing.JTextField txt_gia;
    private javax.swing.JTextField txt_keyWord;
    private javax.swing.JTextField txt_keyWordSP;
    private javax.swing.JTextField txt_maSanPham;
    private javax.swing.JTextField txt_soLuongTon;
    private javax.swing.JTextField txt_tenSanPham;
    // End of variables declaration//GEN-END:variables
}
