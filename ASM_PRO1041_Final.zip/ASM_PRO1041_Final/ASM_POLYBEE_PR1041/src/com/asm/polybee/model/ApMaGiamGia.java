package com.asm.polybee.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ApMaGiamGia {

    private String idApMaGiamGia;
    private String idPhieuGiamGia;
    private String idHoaDon;
}
