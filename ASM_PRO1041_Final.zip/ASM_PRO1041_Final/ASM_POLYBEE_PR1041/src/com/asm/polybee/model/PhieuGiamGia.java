/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.asm.polybee.model;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Zanbo
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class PhieuGiamGia {

    private String idPhieuGiamGia;
    private String maPhieuGiamGia;
    private Date ngayBatDau;
    private Date ngayKetThuc;
    private Integer soLuong;
    private Long giaTriGiamGia;
    private String trangThai;
}
