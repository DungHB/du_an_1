package com.asm.polybee.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class HoaDonChiTiet {

    private String idHoaDonChiTiet;
    private String idHoaDon;
    private String idSanPhamChiTiet;
    private Long donGia;
    private int soLuong;
    private Long thanhTien;
    private String trangThai;
    private String tenSanPham;
    private String size;
    private String mauSac;
    private String tenChatLieu;
}
