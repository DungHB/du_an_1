package com.asm.polybee.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GioHang {

    private String idSanPhamChiTiet;
    private Long donGia;
    private Integer soLuong;
}
