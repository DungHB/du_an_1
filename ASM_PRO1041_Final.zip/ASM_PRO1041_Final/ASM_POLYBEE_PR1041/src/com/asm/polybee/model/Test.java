
package com.asm.polybee.model;

/**
 *
 * @author phuoc
 */
public class Test {
    private String maNV;
    private String tenNhanVien;
    private String phongBan;

    public Test() {
    }
    
    

    public Test(String maNV, String tenNhanVien, String phongBan) {
        this.maNV = maNV;
        this.tenNhanVien = tenNhanVien;
        this.phongBan = phongBan;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getTenNhanVien() {
        return tenNhanVien;
    }

    public void setTenNhanVien(String tenNhanVien) {
        this.tenNhanVien = tenNhanVien;
    }

    public String getPhongBan() {
        return phongBan;
    }

    public void setPhongBan(String phongBan) {
        this.phongBan = phongBan;
    }
    
    
}
