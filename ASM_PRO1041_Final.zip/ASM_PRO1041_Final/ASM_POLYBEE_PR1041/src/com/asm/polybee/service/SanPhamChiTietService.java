package com.asm.polybee.service;

import com.asm.polybee.model.SanPhamChiTiet;
import java.util.List;


public interface SanPhamChiTietService {

    List<SanPhamChiTiet> getAll();

    Boolean themSanPhamChiTiet(SanPhamChiTiet sanPhamChiTiet);

    SanPhamChiTiet getSanPhamChiTietById(String idSanPhamChiTiet);

    boolean capNhatSanPhamChiTiet(SanPhamChiTiet sanPhamChiTiet);

    List<SanPhamChiTiet> getAllSanPhamChiTietViewTable(int offset, int limit);
    
    List<SanPhamChiTiet> getAllSanPhamChiTietViewTableSearch(String searchKeyWord);
    
    int getCountSPCT();

}
