/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.asm.polybee.service;

import com.asm.polybee.model.ThuongHieu;
import java.util.List;

/**
 *
 * @author phuoc
 */
public interface ThuongHieuService {

    List<ThuongHieu> getAll();

    boolean themThuongHieu(ThuongHieu thuongHieu);
    
    ThuongHieu getById(String idThuongHieu);
    
     boolean updateById(ThuongHieu thuongHieu);
}
