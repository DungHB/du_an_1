package com.asm.polybee.service.Impl;

import com.asm.polybee.model.HoaDonChiTiet;
import com.asm.polybee.repository.HoaDonChiTietRepository;
import com.asm.polybee.service.HoaDonChiTietService;
import java.util.List;

public class HoaDonChiTietImpl implements HoaDonChiTietService {

    HoaDonChiTietRepository repository = new HoaDonChiTietRepository();

    @Override
    public List<HoaDonChiTiet> getAll() {
        return repository.getAll();
    }

    @Override
    public boolean themHoaDonChiTiet(HoaDonChiTiet hoaDonChiTiet) {
        if (hoaDonChiTiet != null) {
            repository.themHoaDonChiTiet(hoaDonChiTiet);
            return true;

        } else {
            return false;
        }
    }

    @Override
    public List<HoaDonChiTiet> getAllHoaDonChiTietByIDHoaDon(String idHoaDon) {
        return repository.getAllHoaDonChiTietByIDHoaDon(idHoaDon);
    }

    @Override
    public boolean xoaHoaDonChiTiet(String idHoaDonChiTiet) {
        if (idHoaDonChiTiet != null) {
            repository.xoaHoaDonChiTiet(idHoaDonChiTiet);
            return true;

        } else {
            return false;
        }
    }

    @Override
    public boolean updateHoaDonChiTietByIdHoaDonChiTiet(HoaDonChiTiet hoaDonChiTiet) {
        if (hoaDonChiTiet != null) {
            repository.updateHoaDonChiTietByIdHoaDonChiTiet(hoaDonChiTiet);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public HoaDonChiTiet getAllHoaDonChiTietByIDHoaDonChiTiet(String idHoaDonChiTiet)  {
        return repository.getAllHoaDonChiTietByIDHoaDonChiTiet(idHoaDonChiTiet);
    }

    @Override
    public List<HoaDonChiTiet> getAllGioHangByIDHoaDon(String idHoaDon) {
        return repository.getAllGioHangByIDHoaDon(idHoaDon);
    }

}
