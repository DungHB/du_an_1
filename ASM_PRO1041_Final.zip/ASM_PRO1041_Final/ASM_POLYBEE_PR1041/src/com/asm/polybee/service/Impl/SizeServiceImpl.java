package com.asm.polybee.service.Impl;

import com.asm.polybee.model.Size;
import com.asm.polybee.repository.SizeRepository;
import com.asm.polybee.service.SizeService;
import java.util.List;

/**
 *
 * @author phuoc
 */
public class SizeServiceImpl implements SizeService {

    private SizeRepository repository = new SizeRepository();

    @Override
    public List<Size> getAll() {

        return repository.getAll();
    }

    @Override
    public Boolean themSize(Size size) {
        if (size != null) {
            repository.themSize(size);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public Size getById(String idSize) {
        return repository.getById(idSize);
    }

    @Override
    public boolean updateById(Size size) {
        return repository.updateById(size);
    }

}
