/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.asm.polybee.service;

import com.asm.polybee.model.HoaDonChiTiet;
import java.util.List;

/**
 *
 * @author phuoc
 */
public interface HoaDonChiTietService {

    List<HoaDonChiTiet> getAll();

    boolean themHoaDonChiTiet(HoaDonChiTiet hoaDonChiTiet);

    List<HoaDonChiTiet> getAllHoaDonChiTietByIDHoaDon(String idHoaDon);

    boolean xoaHoaDonChiTiet(String idHoaDonChiTiet);
    
    boolean updateHoaDonChiTietByIdHoaDonChiTiet(HoaDonChiTiet hoaDonChiTiet);
    
    HoaDonChiTiet getAllHoaDonChiTietByIDHoaDonChiTiet(String idHoaDonChiTiet) ;

    List<HoaDonChiTiet> getAllGioHangByIDHoaDon(String idHoaDon);
}
