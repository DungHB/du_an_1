package com.asm.polybee.service.Impl;

import com.asm.polybee.model.SanPhamChiTiet;
import com.asm.polybee.repository.SanPhamChiTietRepository;
import java.util.List;

public class SanPhamChiTietServiceImpl implements com.asm.polybee.service.SanPhamChiTietService {

    private SanPhamChiTietRepository repository = new SanPhamChiTietRepository();

    @Override
    public List<SanPhamChiTiet> getAll() {
        return repository.getAllSanPhamChiTiet();
    }

    @Override
    public Boolean themSanPhamChiTiet(SanPhamChiTiet sanPhamChiTiet) {
        try {
            repository.themSanPhamChiTiet(sanPhamChiTiet);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public SanPhamChiTiet getSanPhamChiTietById(String idSanPhamChiTiet) {
        return repository.getSanPhamChiTietById(idSanPhamChiTiet);
    }

    @Override
    public boolean capNhatSanPhamChiTiet(SanPhamChiTiet sanPhamChiTiet) {
        if (sanPhamChiTiet != null) {
            repository.capNhatSanPhamChiTiet(sanPhamChiTiet);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<SanPhamChiTiet> getAllSanPhamChiTietViewTable(int offset, int limit) {
        return repository.getAllSanPhamChiTietViewTable(offset, limit);
    }

    @Override
    public List<SanPhamChiTiet> getAllSanPhamChiTietViewTableSearch(String searchKeyWord) {
        return repository.getAllSanPhamChiTietViewTableSearch(searchKeyWord);
    }

    @Override
    public int getCountSPCT() {
        return repository.getCountSPCT();
    }

}
