package com.asm.polybee.service.Impl;

import com.asm.polybee.model.NhanVien;
import com.asm.polybee.repository.NhanVienRepository;
import com.asm.polybee.service.NhanVienService;
import java.util.List;

public class NhanVienServiceImpl implements NhanVienService {

    private NhanVienRepository nhanVienRepository = new NhanVienRepository();

    @Override
    public List<NhanVien> getAll() {
        return nhanVienRepository.getAll();
    }

    @Override
    public NhanVien getLoginInfo(String maNhanVien, String matKhau) {
        return nhanVienRepository.getLoginInfo(maNhanVien, matKhau);
    }

    @Override
    public boolean themNhanVien(NhanVien nhanVien) {
        if (nhanVien != null) {
            nhanVienRepository.themNhanVien(nhanVien);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public NhanVien getNhanVienByIdNhanVien(String idNhanVien) {
        return nhanVienRepository.getNhanVienByIdNhanVien(idNhanVien);
    }

    @Override
    public List<NhanVien> getAllViewTable() {
        return nhanVienRepository.getAllViewTable();
    }

    @Override
    public boolean suaThongTinNhanVien(NhanVien nhanVien) {
        return nhanVienRepository.suaThongTinNhanVien(nhanVien);
    }

    @Override
    public NhanVien getNhanVienByMaNhanVien(String maNhanVien) {
        return nhanVienRepository.getNhanVienByMaNhanVien(maNhanVien);
    }

    @Override
    public List<NhanVien> getAllViewTableByPage(int offset, int limit) {
        return nhanVienRepository.getAllViewTableByPage(offset, limit);
    }

    @Override
    public int getCountNhanVien() {
        return nhanVienRepository.getCountNhanVien();
    }

    @Override
    public List<NhanVien> getAllViewTableSearch(String keyWord) {
        return nhanVienRepository.getAllViewTableSearch(keyWord);
    }

}
