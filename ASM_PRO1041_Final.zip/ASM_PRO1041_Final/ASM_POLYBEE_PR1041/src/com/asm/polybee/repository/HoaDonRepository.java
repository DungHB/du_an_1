package com.asm.polybee.repository;

import com.asm.polybee.model.HoaDon;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ultil.JDBC;

public class HoaDonRepository {

    private static final String SQL_GET_ALL = "SELECT * FROM HoaDon";

    private static final String SQL_GET_ALL_VIEW_TABLE = "SELECT \n"
            + "    HD.IdHoaDon, \n"
            + "    HD.MaHoaDon , \n"
            + "    HD.NgayTao , \n"
            + "    HD.TrangThai, \n"
            + "    HD.TongTien , \n"
            + "    NV.TenNhanVien, \n"
            + "    KH.TenKhachHang,\n"
            + "    HD.TrangThai\n"
            + "FROM \n"
            + "    HoaDon HD\n"
            + "INNER JOIN \n"
            + "    NhanVien NV ON HD.IdNhanVien = NV.IdNhanVien\n"
            + "LEFT JOIN \n"
            + "    KhachHang KH ON HD.IdKhachHang = KH.IdKhachHang";

    private static final String SQL_INSERT_HOADON = "INSERT INTO HoaDon ( MaHoaDon, NgayTao, GhiChu, IdNhanVien, IdKhachHang,TrangThai) VALUES (?, ?, ?, ?, ?, ?)";

    private static final String SQL_UPDATE_HOADON = "UPDATE HoaDon SET GhiChu=?, IdNhanVien=?, IdKhachHang=?, TongTien=?, TrangThai=? WHERE IdHoaDon=?";

    private static final String SQL_GET_BY_IDHOADON = "SELECT * FROM HoaDon WHERE IdHoaDon=?";

    private static final String SQL_GET_BY_MAHOADON = "SELECT * FROM HoaDon WHERE MaHoaDon=?";

    private static final String SQL_GET_BY_TRANGTHAI = "SELECT * FROM HoaDon WHERE TrangThai=?";

    private static final String SQL_GET_BY_CONDITIONS = ""
            + "SELECT \n"
            + "    HD.IdHoaDon, \n"
            + "    HD.MaHoaDon , \n"
            + "    HD.NgayTao , \n"
            + "    HD.TrangThai, \n"
            + "    HD.TongTien , \n"
            + "    HD.IdNhanVien, \n"
            + "    KH.TenKhachHang,\n"
            + "	HD.TrangThai\n"
            + "FROM \n"
            + "    HoaDon HD\n"
            + "LEFT JOIN \n"
            + "    KhachHang KH ON HD.IdKhachHang = KH.IdKhachHang\n"
            + "\n"
            + "WHERE NgayTao BETWEEN ? AND ? AND HD.IdNhanVien = ?";

    private static final String SQL_GET_BY_CONDITIONS2 = ""
            + "SELECT \n"
            + "    HD.IdHoaDon, \n"
            + "    HD.MaHoaDon , \n"
            + "    HD.NgayTao , \n"
            + "    HD.TrangThai, \n"
            + "    HD.TongTien , \n"
            + "    HD.IdNhanVien, \n"
            + "    KH.TenKhachHang,\n"
            + "	HD.TrangThai\n"
            + "FROM \n"
            + "    HoaDon HD\n"
            + "INNER JOIN \n"
            + "    NhanVien NV ON HD.IdNhanVien = NV.IdNhanVien\n"
            + "LEFT JOIN \n"
            + "    KhachHang KH ON HD.IdKhachHang = KH.IdKhachHang\n"
            + "\n"
            + "WHERE NgayTao BETWEEN ? AND ?";

    public List<HoaDon> getAll() {
        List<HoaDon> hoaDons = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_ALL);  ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                HoaDon hoaDon = new HoaDon();
                hoaDon.setIdHoaDon(resultSet.getString("IdHoaDon"));
                hoaDon.setMaHoaDon(resultSet.getString("MaHoaDon"));
                hoaDon.setNgayTao(resultSet.getDate("NgayTao"));
                hoaDon.setGhiChu(resultSet.getString("GhiChu"));
                hoaDon.setIdNhanVien(resultSet.getString("IdNhanVien"));
                hoaDon.setIdKhachHang(resultSet.getString("IdKhachHang"));
                hoaDon.setTongTien(resultSet.getLong("TongTien"));
                hoaDon.setTrangThai(resultSet.getString("TrangThai"));
                hoaDons.add(hoaDon);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDons;
    }

    public List<HoaDon> getAllViewTable() {
        List<HoaDon> hoaDons = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_ALL_VIEW_TABLE);  ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                HoaDon hoaDon = new HoaDon();
                hoaDon.setIdHoaDon(resultSet.getString("IdHoaDon"));
                hoaDon.setMaHoaDon(resultSet.getString("MaHoaDon"));
                hoaDon.setNgayTao(resultSet.getDate("NgayTao"));
                hoaDon.setTenNhanVien(resultSet.getString("TenNhanVien"));
                hoaDon.setTenKhachHang(resultSet.getString("TenKhachHang"));
                hoaDon.setTongTien(resultSet.getLong("TongTien"));
                hoaDon.setTrangThai(resultSet.getString("TrangThai"));
                hoaDons.add(hoaDon);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDons;
    }

    public void themHoaDon(HoaDon hoaDon) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_INSERT_HOADON)) {

            preparedStatement.setString(1, hoaDon.getMaHoaDon());
            preparedStatement.setDate(2, new java.sql.Date(hoaDon.getNgayTao().getTime()));
            preparedStatement.setString(3, hoaDon.getGhiChu());
            preparedStatement.setString(4, hoaDon.getIdNhanVien());
            preparedStatement.setString(5, hoaDon.getIdKhachHang());
            preparedStatement.setString(6, hoaDon.getTrangThai());

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public HoaDon getHoaDonByMaHoaDon(String maHoaDon) {
        HoaDon hoaDon = null;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_BY_IDHOADON)) {

            preparedStatement.setString(1, maHoaDon);

            try ( ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    hoaDon = new HoaDon();
                    hoaDon.setIdHoaDon(resultSet.getString("IdHoaDon"));
                    hoaDon.setMaHoaDon(resultSet.getString("MaHoaDon"));
                    hoaDon.setNgayTao(resultSet.getDate("NgayTao"));
                    hoaDon.setGhiChu(resultSet.getString("GhiChu"));
                    hoaDon.setIdNhanVien(resultSet.getString("IdNhanVien"));
                    hoaDon.setIdKhachHang(resultSet.getString("IdKhachHang"));
                    hoaDon.setTongTien(resultSet.getLong("TongTien"));
                    hoaDon.setTrangThai(resultSet.getString("TrangThai"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDon;
    }

    public HoaDon getHoaDonByMaHoaDon2(String maHoaDon) {
        HoaDon hoaDon = null;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_BY_MAHOADON)) {

            preparedStatement.setString(1, maHoaDon);

            try ( ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    hoaDon = new HoaDon();
                    hoaDon.setIdHoaDon(resultSet.getString("IdHoaDon"));
                    hoaDon.setMaHoaDon(resultSet.getString("MaHoaDon"));
                    hoaDon.setNgayTao(resultSet.getDate("NgayTao"));
                    hoaDon.setGhiChu(resultSet.getString("GhiChu"));
                    hoaDon.setIdNhanVien(resultSet.getString("IdNhanVien"));
                    hoaDon.setIdKhachHang(resultSet.getString("IdKhachHang"));
                    hoaDon.setTongTien(resultSet.getLong("TongTien"));
                    hoaDon.setTrangThai(resultSet.getString("TrangThai"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDon;
    }

    public List<HoaDon> getHoaDonByTrangThai(String trangThai) {
        List<HoaDon> hoaDons = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_BY_TRANGTHAI)) {

            preparedStatement.setString(1, trangThai);

            try ( ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    HoaDon hoaDon = new HoaDon();
                    hoaDon.setIdHoaDon(resultSet.getString("IdHoaDon"));
                    hoaDon.setMaHoaDon(resultSet.getString("MaHoaDon"));
                    hoaDon.setNgayTao(resultSet.getDate("NgayTao"));
                    hoaDon.setGhiChu(resultSet.getString("GhiChu"));
                    hoaDon.setIdNhanVien(resultSet.getString("IdNhanVien"));
                    hoaDon.setIdKhachHang(resultSet.getString("IdKhachHang"));
                    hoaDon.setTongTien(resultSet.getLong("TongTien"));
                    hoaDon.setTrangThai(resultSet.getString("TrangThai"));
                    hoaDons.add(hoaDon);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDons;
    }

    public List<HoaDon> getHoaDonByConditions(Date ngayTu, Date ngayDen, String idNhanVien) {
        List<HoaDon> hoaDons = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_BY_CONDITIONS)) {

            preparedStatement.setDate(1, new java.sql.Date(ngayTu.getTime()));
            preparedStatement.setDate(2, new java.sql.Date(ngayDen.getTime()));
            preparedStatement.setString(3, idNhanVien);

            try ( ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    HoaDon hoaDon = new HoaDon();
                    hoaDon.setIdHoaDon(resultSet.getString("IdHoaDon"));
                    hoaDon.setMaHoaDon(resultSet.getString("MaHoaDon"));
                    hoaDon.setNgayTao(resultSet.getDate("NgayTao"));
                    hoaDon.setIdNhanVien(resultSet.getString("IdNhanVien"));
                    hoaDon.setTenKhachHang(resultSet.getString("TenKhachHang"));
                    hoaDon.setTongTien(resultSet.getLong("TongTien"));
                    hoaDon.setTrangThai(resultSet.getString("TrangThai"));
                    hoaDons.add(hoaDon);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDons;
    }

    public List<HoaDon> getHoaDonByConditions2(Date ngayBatDau, Date ngayKetThuc) {
        List<HoaDon> hoaDons = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_BY_CONDITIONS2)) {

            preparedStatement.setDate(1, new java.sql.Date(ngayBatDau.getTime()));
            preparedStatement.setDate(2, new java.sql.Date(ngayKetThuc.getTime()));

            try ( ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    HoaDon hoaDon = new HoaDon();
                    hoaDon.setIdHoaDon(resultSet.getString("IdHoaDon"));
                    hoaDon.setMaHoaDon(resultSet.getString("MaHoaDon"));
                    hoaDon.setNgayTao(resultSet.getDate("NgayTao"));
                    hoaDon.setIdNhanVien(resultSet.getString("IdNhanVien"));
                    hoaDon.setTenKhachHang(resultSet.getString("TenKhachHang"));
                    hoaDon.setTongTien(resultSet.getLong("TongTien"));
                    hoaDon.setTrangThai(resultSet.getString("TrangThai"));
                    hoaDons.add(hoaDon);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDons;
    }

    public void capNhatHoaDon(HoaDon hoaDon) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_UPDATE_HOADON)) {

            preparedStatement.setString(1, hoaDon.getGhiChu());
            preparedStatement.setString(2, hoaDon.getIdNhanVien());
            preparedStatement.setString(3, hoaDon.getIdKhachHang());
            preparedStatement.setLong(4, hoaDon.getTongTien());
            preparedStatement.setString(5, hoaDon.getTrangThai());
            preparedStatement.setString(6, hoaDon.getIdHoaDon());

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
