/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.asm.polybee.repository;

import com.asm.polybee.model.PhieuGiamGia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ultil.JDBC;

/**
 *
 * @author Zanbo
 */
public class PhieuGiamGiaRepository {

    public static final String SQL_GET_ALL = "SELECT * FROM PhieuGiamGia";

    public static final String SQL_GET_BY_ID = "SELECT * FROM PhieuGiamGia WHERE MaPhieuGiamGia = ?";
    
    public static final String SQL_GET_BY_ID_PHIEU = "SELECT * FROM PhieuGiamGia WHERE IdPhieuGiamGia = ?";

    public static final String SQL_INSERT = "INSERT INTO PhieuGiamGia (IdPhieuGiamGia, MaPhieuGiamGia, NgayBatDau, NgayKetThuc, SoLuong, GiaTriGiamGia, TrangThai)\n"
            + "VALUES (?,?,?,?,?,?,?)";

    public static final String SQL_UPDATE = "UPDATE PhieuGiamGia SET soLuong = ?, trangThai = ? WHERE MaPhieuGiamGia = ?";

    public List<PhieuGiamGia> getAll() {
        List<PhieuGiamGia> phieuGiamGias = new ArrayList<>();

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_ALL)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                PhieuGiamGia phieuGiamGia = new PhieuGiamGia();
                phieuGiamGia.setIdPhieuGiamGia(resultSet.getString("IdPhieuGiamGia"));
                phieuGiamGia.setMaPhieuGiamGia(resultSet.getString("MaPhieuGiamGia"));
                phieuGiamGia.setNgayBatDau(resultSet.getDate("NgayBatDau"));
                phieuGiamGia.setNgayKetThuc(resultSet.getDate("NgayKetThuc"));
                phieuGiamGia.setSoLuong(resultSet.getInt("SoLuong"));
                phieuGiamGia.setGiaTriGiamGia(resultSet.getLong("GiaTriGiamGia"));
                phieuGiamGia.setTrangThai(resultSet.getString("TrangThai"));
                phieuGiamGias.add(phieuGiamGia);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return phieuGiamGias;
    }

    public PhieuGiamGia getById(String maPhieuGiamGia) {
        PhieuGiamGia phieuGiamGia = null;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_ID)) {
            statement.setString(1, maPhieuGiamGia);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                phieuGiamGia = new PhieuGiamGia();
                phieuGiamGia.setIdPhieuGiamGia(resultSet.getString("IdPhieuGiamGia"));
                phieuGiamGia.setMaPhieuGiamGia(resultSet.getString("MaPhieuGiamGia"));
                phieuGiamGia.setNgayBatDau(resultSet.getDate("NgayBatDau"));
                phieuGiamGia.setNgayKetThuc(resultSet.getDate("NgayKetThuc"));
                phieuGiamGia.setSoLuong(resultSet.getInt("SoLuong"));
                phieuGiamGia.setGiaTriGiamGia(resultSet.getLong("GiaTriGiamGia"));
                phieuGiamGia.setTrangThai(resultSet.getString("TrangThai"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return phieuGiamGia;
    }
    
    public PhieuGiamGia getByIdPhieu(String idPhieuGiamGia) {
        PhieuGiamGia phieuGiamGia = null;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_ID_PHIEU)) {
            statement.setString(1, idPhieuGiamGia);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                phieuGiamGia = new PhieuGiamGia();
                phieuGiamGia.setIdPhieuGiamGia(resultSet.getString("IdPhieuGiamGia"));
                phieuGiamGia.setMaPhieuGiamGia(resultSet.getString("MaPhieuGiamGia"));
                phieuGiamGia.setNgayBatDau(resultSet.getDate("NgayBatDau"));
                phieuGiamGia.setNgayKetThuc(resultSet.getDate("NgayKetThuc"));
                phieuGiamGia.setSoLuong(resultSet.getInt("SoLuong"));
                phieuGiamGia.setGiaTriGiamGia(resultSet.getLong("GiaTriGiamGia"));
                phieuGiamGia.setTrangThai(resultSet.getString("TrangThai"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return phieuGiamGia;
    }

    public void insert(PhieuGiamGia phieuGiamGia) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_INSERT)) {
            statement.setString(1, phieuGiamGia.getIdPhieuGiamGia());
            statement.setString(2, phieuGiamGia.getMaPhieuGiamGia());
            statement.setDate(3, new java.sql.Date(phieuGiamGia.getNgayBatDau().getTime()));
            statement.setDate(4, new java.sql.Date(phieuGiamGia.getNgayKetThuc().getTime()));
            statement.setInt(5, phieuGiamGia.getSoLuong());
            statement.setLong(6, phieuGiamGia.getGiaTriGiamGia());
            statement.setString(7, phieuGiamGia.getTrangThai());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void update(PhieuGiamGia phieuGiamGia) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_UPDATE)) {
            statement.setInt(1, phieuGiamGia.getSoLuong());
            statement.setString(2, phieuGiamGia.getTrangThai());
            statement.setString(3, phieuGiamGia.getMaPhieuGiamGia()); // Đặt giá trị cho IdPhieuGiamGia
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
