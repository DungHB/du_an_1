package com.asm.polybee.repository;

import com.asm.polybee.model.HoaDonChiTiet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ultil.JDBC;

public class HoaDonChiTietRepository {

    private static final String SQL_GET_ALL = "SELECT * FROM HoaDonChiTiet";

    private static final String SQL_GET_GIO_HANG_BY_ID = "SELECT HDT.IdHoaDonChiTiet, SP.TenSanPham, SZ.Size, MS.TenMauSac, HDT.SoLuong, SPC.Gia, HDT.ThanhTien, SPC.IdSanPhamChiTiet,CL.TenChatLieu\n"
            + "FROM HoaDonChiTiet HDT\n"
            + "INNER JOIN SanPhamChiTiet SPC ON HDT.IdSanPhamChiTiet = SPC.IdSanPhamChiTiet\n"
            + "INNER JOIN SanPham SP ON SPC.IdSanPham = SP.IdSanPham\n"
            + "INNER JOIN Size SZ ON SPC.IdSize = SZ.IdSize\n"
            + "INNER JOIN MauSac MS ON SPC.IdMauSac = MS.IdMauSac\n"
            + "INNER JOIN HoaDon HD ON HDT.IdHoaDon = HD.IdHoaDon\n"
            + "INNER JOIN ChatLieu CL ON SPC.IdChatLieu = CL.IdChatLieu\n"
            + "WHERE HD.IdHoaDon = ?";

    private static final String SQL_INSERT_HOADONCHITIET = "INSERT INTO HoaDonChiTiet (IdHoaDon, IdSanPhamChiTiet, DonGia, SoLuong, ThanhTien, TrangThai) VALUES (?, ?, ?, ?, ?, ?)";

    private static final String SQL_GET_BY_ID_HOA_DON = "SELECT * FROM HoaDonChiTiet WHERE IdHoaDon = ?";

    private static final String SQL_GET_BY_ID_HOA_DON_CHI_TIET = "SELECT * FROM HoaDonChiTiet WHERE IdHoaDonChiTiet = ?";

    private static final String SQL_DELETE = "DELETE FROM HoaDonChiTiet WHERE IdHoaDonChiTiet = ?";

    private static final String SQL_UPDATE_BY_ID_HOA_DON_CHI_TIET = "UPDATE HoaDonChiTiet SET IdHoaDon = ?, IdSanPhamChiTiet = ?, DonGia = ?, SoLuong = ?, ThanhTien = ?, TrangThai = ? WHERE IdHoaDonChiTiet = ?";

    public List<HoaDonChiTiet> getAll() {
        List<HoaDonChiTiet> hoaDonChiTiets = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_ALL);  ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                HoaDonChiTiet hoaDonChiTiet = new HoaDonChiTiet();
                hoaDonChiTiet.setIdHoaDonChiTiet(resultSet.getString("IdHoaDonChiTiet"));
                hoaDonChiTiet.setIdHoaDon(resultSet.getString("IdHoaDon"));
                hoaDonChiTiet.setIdSanPhamChiTiet(resultSet.getString("IdSanPhamChiTiet"));
                hoaDonChiTiet.setDonGia(resultSet.getLong("DonGia"));
                hoaDonChiTiet.setSoLuong(resultSet.getInt("SoLuong"));
                hoaDonChiTiet.setThanhTien(resultSet.getLong("ThanhTien"));
                hoaDonChiTiet.setTrangThai(resultSet.getString("TrangThai"));
                hoaDonChiTiets.add(hoaDonChiTiet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDonChiTiets;
    }

    public void themHoaDonChiTiet(HoaDonChiTiet hoaDonChiTiet) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_INSERT_HOADONCHITIET)) {

            preparedStatement.setString(1, hoaDonChiTiet.getIdHoaDon());
            preparedStatement.setString(2, hoaDonChiTiet.getIdSanPhamChiTiet());
            preparedStatement.setLong(3, hoaDonChiTiet.getDonGia());
            preparedStatement.setInt(4, hoaDonChiTiet.getSoLuong());
            preparedStatement.setLong(5, hoaDonChiTiet.getThanhTien());
            preparedStatement.setString(6, hoaDonChiTiet.getTrangThai());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<HoaDonChiTiet> getAllHoaDonChiTietByIDHoaDon(String idHoaDon) {
        List<HoaDonChiTiet> hoaDonChiTiets = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_BY_ID_HOA_DON)) {

            preparedStatement.setString(1, idHoaDon);

            try ( ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    HoaDonChiTiet hoaDonChiTiet = new HoaDonChiTiet();
                    hoaDonChiTiet.setIdHoaDonChiTiet(resultSet.getString("IdHoaDonChiTiet"));
                    hoaDonChiTiet.setIdHoaDon(resultSet.getString("IdHoaDon"));
                    hoaDonChiTiet.setIdSanPhamChiTiet(resultSet.getString("IdSanPhamChiTiet"));
                    hoaDonChiTiet.setDonGia(resultSet.getLong("DonGia"));
                    hoaDonChiTiet.setSoLuong(resultSet.getInt("SoLuong"));
                    hoaDonChiTiet.setThanhTien(resultSet.getLong("ThanhTien"));
                    hoaDonChiTiet.setTrangThai(resultSet.getString("TrangThai"));
                    hoaDonChiTiets.add(hoaDonChiTiet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDonChiTiets;
    }

    public List<HoaDonChiTiet> getAllGioHangByIDHoaDon(String idHoaDon) {
        List<HoaDonChiTiet> hoaDonChiTiets = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_GIO_HANG_BY_ID)) {

            preparedStatement.setString(1, idHoaDon);

            try ( ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    HoaDonChiTiet hoaDonChiTiet = new HoaDonChiTiet();
                    hoaDonChiTiet.setIdHoaDonChiTiet(resultSet.getString("IdHoaDonChiTiet"));
                    hoaDonChiTiet.setTenSanPham(resultSet.getString("TenSanPham"));
                    hoaDonChiTiet.setSize(resultSet.getString("Size"));
                    hoaDonChiTiet.setMauSac(resultSet.getString("TenMauSac"));
                    hoaDonChiTiet.setSoLuong(resultSet.getInt("SoLuong"));
                    hoaDonChiTiet.setTenChatLieu(resultSet.getString("TenChatLieu"));
                    hoaDonChiTiet.setDonGia(resultSet.getLong("Gia"));
                    hoaDonChiTiet.setThanhTien(resultSet.getLong("ThanhTien"));
                    hoaDonChiTiet.setIdSanPhamChiTiet(resultSet.getString("IdSanPhamChiTiet"));

                    hoaDonChiTiets.add(hoaDonChiTiet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDonChiTiets;
    }

    public HoaDonChiTiet getAllHoaDonChiTietByIDHoaDonChiTiet(String idHoaDonChiTiet) {
        HoaDonChiTiet hoaDonChiTiet = null;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_BY_ID_HOA_DON_CHI_TIET)) {

            preparedStatement.setString(1, idHoaDonChiTiet);

            try ( ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    hoaDonChiTiet = new HoaDonChiTiet();
                    hoaDonChiTiet.setIdHoaDonChiTiet(resultSet.getString("IdHoaDonChiTiet"));
                    hoaDonChiTiet.setIdHoaDon(resultSet.getString("IdHoaDon"));
                    hoaDonChiTiet.setIdSanPhamChiTiet(resultSet.getString("IdSanPhamChiTiet"));
                    hoaDonChiTiet.setDonGia(resultSet.getLong("DonGia"));
                    hoaDonChiTiet.setSoLuong(resultSet.getInt("SoLuong"));
                    hoaDonChiTiet.setThanhTien(resultSet.getLong("ThanhTien"));
                    hoaDonChiTiet.setTrangThai(resultSet.getString("TrangThai"));

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hoaDonChiTiet;
    }

    public boolean xoaHoaDonChiTiet(String idHoaDonChiTiet) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_DELETE)) {
            statement.setString(1, idHoaDonChiTiet);

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void updateHoaDonChiTietByIdHoaDonChiTiet(HoaDonChiTiet hoaDonChiTiet) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement preparedStatement = connection.prepareStatement(SQL_UPDATE_BY_ID_HOA_DON_CHI_TIET)) {
            preparedStatement.setString(1, hoaDonChiTiet.getIdHoaDon());
            preparedStatement.setString(2, hoaDonChiTiet.getIdSanPhamChiTiet());
            preparedStatement.setLong(3, hoaDonChiTiet.getDonGia());
            preparedStatement.setInt(4, hoaDonChiTiet.getSoLuong());
            preparedStatement.setLong(5, hoaDonChiTiet.getThanhTien());
            preparedStatement.setString(6, hoaDonChiTiet.getTrangThai());
            preparedStatement.setString(7, hoaDonChiTiet.getIdHoaDonChiTiet());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        HoaDonChiTietRepository repository = new HoaDonChiTietRepository();

        // Thay đổi giá trị idHoaDon bằng mã hóa đơn thực tế của bạn
        String idHoaDon = "903C52CB-6DE3-4181-9887-09E817B89A0E";

        List<HoaDonChiTiet> gioHang = repository.getAllGioHangByIDHoaDon(idHoaDon);

        // In ra thông tin các mặt hàng trong giỏ hàng
        for (HoaDonChiTiet item : gioHang) {
            System.out.println("ID Hóa Đơn Chi Tiết: " + item.getIdHoaDonChiTiet());
            System.out.println("Tên Sản Phẩm: " + item.getTenSanPham());
            System.out.println("Size: " + item.getSize());
            System.out.println("Màu Sắc: " + item.getMauSac());
            System.out.println("Số Lượng: " + item.getSoLuong());
            System.out.println("Đơn Giá: " + item.getDonGia());
            System.out.println("Thành Tiền: " + item.getThanhTien());
            System.out.println("--------------------------------");
        }
    }

}
