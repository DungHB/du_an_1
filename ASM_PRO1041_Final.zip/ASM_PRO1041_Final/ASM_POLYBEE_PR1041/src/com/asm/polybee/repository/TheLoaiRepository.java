/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.asm.polybee.repository;

import com.asm.polybee.model.TheLoai;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import ultil.JDBC;

/**
 *
 * @author phuoc
 */
public class TheLoaiRepository {

    private static final String SQL_GET_ALL = "SELECT * FROM TheLoai";
    private static final String SQL_GET_BY_ID = "SELECT * FROM TheLoai WHERE IdTheLoai = ?";
    private static final String SQL_UPDATE = "UPDATE TheLoai SET TenTheLoai = ?, MaTheLoai = ? WHERE IdTheLoai = ?";

    public List<TheLoai> getAll() {
        List<TheLoai> theLoais = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  Statement statement = connection.createStatement();  ResultSet resultSet = statement.executeQuery(SQL_GET_ALL)) {
            while (resultSet.next()) {
                TheLoai theLoai = new TheLoai();
                theLoai.setIdTheloai(resultSet.getString("IdTheLoai"));
                theLoai.setTenTheLoai(resultSet.getString("TenTheLoai"));
                theLoai.setMaTheLoai(resultSet.getString("MaTheLoai"));
                theLoais.add(theLoai);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return theLoais;
    }

    // Hàm lấy thể loại theo ID
    public TheLoai getTheLoaiByID(String idTheLoai) {
        TheLoai theLoai = null;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_ID)) {
            statement.setString(1, idTheLoai);
            try ( ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    theLoai = new TheLoai();
                    theLoai.setIdTheloai(resultSet.getString("IdTheLoai"));
                    theLoai.setTenTheLoai(resultSet.getString("TenTheLoai"));
                    theLoai.setMaTheLoai(resultSet.getString("MaTheLoai"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return theLoai;
    }

    // Hàm cập nhật thông tin thể loại
    public boolean updateTheLoai(TheLoai theLoai) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_UPDATE)) {
            statement.setString(1, theLoai.getTenTheLoai());
            statement.setString(2, theLoai.getMaTheLoai());
            statement.setString(3, theLoai.getIdTheloai());

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean themTheLoai(TheLoai theLoai) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement("INSERT INTO TheLoai (TenTheLoai, MaTheLoai) VALUES ( ?,?)")) {
            statement.setString(1, theLoai.getTenTheLoai());
            statement.setString(2, theLoai.getMaTheLoai());
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
