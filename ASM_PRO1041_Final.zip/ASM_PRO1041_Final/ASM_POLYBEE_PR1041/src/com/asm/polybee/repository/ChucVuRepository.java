package com.asm.polybee.repository;

import com.asm.polybee.model.ChucVu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import ultil.JDBC;

public class ChucVuRepository {

    private static final String SQL_GET_ALL = "SELECT * FROM ChucVu";

    private static final String SQL_GET_BY_ID = "SELECT * FROM ChucVu WHERE IdChucVu = ?";

    public List<ChucVu> getAll() {
        List<ChucVu> chucVus = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  Statement statement = connection.createStatement();  ResultSet resultSet = statement.executeQuery(SQL_GET_ALL)) {
            while (resultSet.next()) {
                ChucVu chucVu = mapChucVu(resultSet);
                chucVus.add(chucVu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return chucVus;
    }

    private ChucVu mapChucVu(ResultSet resultSet) throws SQLException {
        ChucVu chucVu = new ChucVu();
        chucVu.setIdChucVu(resultSet.getString("idChucVu"));
        chucVu.setMaChucVu(resultSet.getString("maChucVu"));
        chucVu.setTenChucVu(resultSet.getString("tenChucVu"));
        return chucVu;
    }

    public ChucVu getChucVuById(String idChucVu) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_ID)) {
            statement.setString(1, idChucVu);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return mapChucVu(resultSet);
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

}
