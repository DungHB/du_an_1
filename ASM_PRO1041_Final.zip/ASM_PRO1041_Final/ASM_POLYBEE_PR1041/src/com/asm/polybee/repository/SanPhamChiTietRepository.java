package com.asm.polybee.repository;

import com.asm.polybee.model.SanPhamChiTiet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ultil.JDBC;

/**
 *
 * @author phuoc
 */
public class SanPhamChiTietRepository {

    private static final String SQL_GET_ALL = "SELECT spct.*, mau.TenMauSac, cl.TenChatLieu, size.Size "
            + "FROM SanPhamChiTiet spct "
            + "JOIN MauSac mau ON spct.IdMauSac = mau.IdMauSac "
            + "JOIN ChatLieu cl ON spct.IdChatLieu = cl.IdChatLieu "
            + "JOIN Size size ON spct.IdSize = size.IdSize";

    private static final String SQL_GET_ALL_VIEW_TABLE = "SELECT S.IdSanPhamChiTiet, SanPham.TenSanPham , Size.Size, MauSac.TenMauSac, ChatLieu.TenChatLieu, S.SoLuong, S.Gia\n"
            + "FROM SanPhamChiTiet S\n"
            + "JOIN Size ON S.IdSize = Size.IdSize\n"
            + "JOIN MauSac ON S.IdMauSac = MauSac.IdMauSac\n"
            + "JOIN ChatLieu ON S.IdChatLieu = ChatLieu.IdChatLieu\n"
            + "JOIN SanPham ON S.IdSanPham = SanPham.IdSanPham\n"
            + "WHERE SanPham.TrangThai = N'Hoạt động'\n"
            + "ORDER BY S.IdSanPhamChiTiet\n"
            + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    private static final String SQL_GET_ALL_VIEW_TABLE_WITH_SEARCH = "SELECT S.IdSanPhamChiTiet, SanPham.TenSanPham , Size.Size, MauSac.TenMauSac, ChatLieu.TenChatLieu, S.SoLuong, S.Gia\n"
            + "FROM SanPhamChiTiet S\n"
            + "JOIN Size ON S.IdSize = Size.IdSize\n"
            + "JOIN MauSac ON S.IdMauSac = MauSac.IdMauSac\n"
            + "JOIN ChatLieu ON S.IdChatLieu = ChatLieu.IdChatLieu\n"
            + "JOIN SanPham ON S.IdSanPham = SanPham.IdSanPham\n"
            + "WHERE CONCAT(SanPham.TenSanPham, ' ', MauSac.TenMauSac, ' ', ChatLieu.TenChatLieu) LIKE '%' + ? + '%'";

    private static final String SQL_INSERT = "INSERT INTO SanPhamChiTiet ( IdSanPham, IdChatLieu, IdMauSac, IdSize, Gia, SoLuong) VALUES ( ?, ?, ?, ?, ?, ?)";

    private static final String SQL_GET_BY_ID = "SELECT spct.*, mau.TenMauSac, cl.TenChatLieu, size.Size "
            + "FROM SanPhamChiTiet spct "
            + "JOIN MauSac mau ON spct.IdMauSac = mau.IdMauSac "
            + "JOIN ChatLieu cl ON spct.IdChatLieu = cl.IdChatLieu "
            + "JOIN Size size ON spct.IdSize = size.IdSize "
            + "WHERE spct.IdSanPhamChiTiet = ?";

    private static final String SQL_UPDATE = "UPDATE SanPhamChiTiet SET IdChatLieu = ?, IdMauSac = ?, IdSize = ?, Gia = ?, SoLuong = ? WHERE IdSanPhamChiTiet = ?";

    private static final String COUNT_SPCT = "SELECT COUNT(*) FROM SanPhamChiTiet";

    public List<SanPhamChiTiet> getAllSanPhamChiTiet() {
        List<SanPhamChiTiet> sanPhamChiTiets = new ArrayList<>();

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_ALL)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                SanPhamChiTiet sanPhamChiTiet = new SanPhamChiTiet();
                sanPhamChiTiet.setIdSanPhamChiTiet(resultSet.getString("IdSanPhamChiTiet"));
                sanPhamChiTiet.setIdSanPham(resultSet.getString("IdSanPham"));
                sanPhamChiTiet.setIdChatLieu(resultSet.getString("IdChatLieu"));
                sanPhamChiTiet.setIdMauSac(resultSet.getString("IdMauSac"));
                sanPhamChiTiet.setIdSize(resultSet.getString("IdSize"));
                sanPhamChiTiet.setGia(resultSet.getLong("Gia"));
                sanPhamChiTiet.setSoLuong(resultSet.getInt("SoLuong"));
                sanPhamChiTiets.add(sanPhamChiTiet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sanPhamChiTiets;
    }

    public List<SanPhamChiTiet> getAllSanPhamChiTietViewTable(int offset, int limit) {
        List<SanPhamChiTiet> sanPhamChiTiets = new ArrayList<>();

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_ALL_VIEW_TABLE)) {
            statement.setInt(1, offset);
            statement.setInt(2, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                SanPhamChiTiet sanPhamChiTiet = new SanPhamChiTiet();
                sanPhamChiTiet.setIdSanPhamChiTiet(resultSet.getString("IdSanPhamChiTiet"));
                sanPhamChiTiet.setTenSanPham(resultSet.getString("TenSanPham"));
                sanPhamChiTiet.setTenChatLieu(resultSet.getString("TenChatLieu"));
                sanPhamChiTiet.setTenMauSac(resultSet.getString("TenMauSac"));
                sanPhamChiTiet.setSize(resultSet.getString("Size"));
                sanPhamChiTiet.setGia(resultSet.getLong("Gia"));
                sanPhamChiTiet.setSoLuong(resultSet.getInt("SoLuong"));
                sanPhamChiTiets.add(sanPhamChiTiet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sanPhamChiTiets;
    }

    public int getCountSPCT() {
        int count = 0;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(COUNT_SPCT)) {
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public List<SanPhamChiTiet> getAllSanPhamChiTietViewTableSearch(String searchKeyWord) {
        List<SanPhamChiTiet> sanPhamChiTiets = new ArrayList<>();

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_ALL_VIEW_TABLE_WITH_SEARCH)) {
            statement.setString(1, searchKeyWord);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                SanPhamChiTiet sanPhamChiTiet = new SanPhamChiTiet();
                sanPhamChiTiet.setIdSanPhamChiTiet(resultSet.getString("IdSanPhamChiTiet"));
                sanPhamChiTiet.setTenSanPham(resultSet.getString("TenSanPham"));
                sanPhamChiTiet.setTenChatLieu(resultSet.getString("TenChatLieu"));
                sanPhamChiTiet.setTenMauSac(resultSet.getString("TenMauSac"));
                sanPhamChiTiet.setSize(resultSet.getString("Size"));
                sanPhamChiTiet.setGia(resultSet.getLong("Gia"));
                sanPhamChiTiet.setSoLuong(resultSet.getInt("SoLuong"));
                sanPhamChiTiets.add(sanPhamChiTiet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sanPhamChiTiets;
    }

    public boolean themSanPhamChiTiet(SanPhamChiTiet sanPhamChiTiet) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_INSERT)) {
            statement.setString(1, sanPhamChiTiet.getIdSanPham());
            statement.setString(2, sanPhamChiTiet.getIdChatLieu());
            statement.setString(3, sanPhamChiTiet.getIdMauSac());
            statement.setString(4, sanPhamChiTiet.getIdSize());
            statement.setLong(5, sanPhamChiTiet.getGia());
            statement.setInt(6, sanPhamChiTiet.getSoLuong());

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public SanPhamChiTiet getSanPhamChiTietById(String idSanPhamChiTiet) {
        SanPhamChiTiet sanPhamChiTiet = null;

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_ID)) {
            statement.setString(1, idSanPhamChiTiet);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                sanPhamChiTiet = new SanPhamChiTiet();
                sanPhamChiTiet.setIdSanPhamChiTiet(resultSet.getString("IdSanPhamChiTiet"));
                sanPhamChiTiet.setIdSanPham(resultSet.getString("IdSanPham"));
                sanPhamChiTiet.setIdChatLieu(resultSet.getString("IdChatLieu"));
                sanPhamChiTiet.setIdMauSac(resultSet.getString("IdMauSac"));
                sanPhamChiTiet.setIdSize(resultSet.getString("IdSize"));
                sanPhamChiTiet.setGia(resultSet.getLong("Gia"));
                sanPhamChiTiet.setSoLuong(resultSet.getInt("SoLuong"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sanPhamChiTiet;
    }

    public boolean capNhatSanPhamChiTiet(SanPhamChiTiet sanPhamChiTiet) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_UPDATE)) {
            statement.setString(1, sanPhamChiTiet.getIdChatLieu());
            statement.setString(2, sanPhamChiTiet.getIdMauSac());
            statement.setString(3, sanPhamChiTiet.getIdSize());
            statement.setLong(4, sanPhamChiTiet.getGia());
            statement.setInt(5, sanPhamChiTiet.getSoLuong());
            statement.setString(6, sanPhamChiTiet.getIdSanPhamChiTiet());

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
