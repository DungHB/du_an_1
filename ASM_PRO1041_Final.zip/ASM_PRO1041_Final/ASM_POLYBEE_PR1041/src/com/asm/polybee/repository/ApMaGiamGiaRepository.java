/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.asm.polybee.repository;

import com.asm.polybee.model.ApMaGiamGia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ultil.JDBC;

/**
 *
 * @author Zanbo
 */
public class ApMaGiamGiaRepository {

    public static final String SQL_GET_ID_PHIEU_GIAM_GIA_BY_ID_HOA_DON = "SELECT IdPhieuGiamGia FROM ApMaGiamGia WHERE IdHoaDon = ?";
    public static final String SQL_INSERT = "INSERT INTO ApMaGiamGia (IdApMaGiamGia, IdPhieuGiamGia, IdHoaDon) VALUES (NEWID(), ?, ?)";
    public static final String SQL_DELETE_BY_ID_HOA_DON = "DELETE FROM ApMaGiamGia WHERE IdHoaDon = ?";

    public String getIdPhieuGiamGiaByIdHoaDon(String idHoaDon) {
        String idPhieuGiamGia = null;

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_ID_PHIEU_GIAM_GIA_BY_ID_HOA_DON)) {
            statement.setString(1, idHoaDon);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                idPhieuGiamGia = resultSet.getString("IdPhieuGiamGia");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return idPhieuGiamGia;
    }

    public void insert(ApMaGiamGia apMaGiamGia) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_INSERT)) {
            statement.setString(1, apMaGiamGia.getIdPhieuGiamGia());
            statement.setString(2, apMaGiamGia.getIdHoaDon());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteByIdHoaDon(String idHoaDon) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_DELETE_BY_ID_HOA_DON)) {
            statement.setString(1, idHoaDon);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
