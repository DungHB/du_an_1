package com.asm.polybee.repository;

import com.asm.polybee.model.NhanVien;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import ultil.JDBC;

public class NhanVienRepository {

    private static final String SQL_GET_ALL = "SELECT * FROM NhanVien";

    private static final String SQL_GET_ALL_VIEW_TABLE = "SELECT N.*, CV.TenChucVu\n"
            + "FROM NhanVien N\n"
            + "LEFT JOIN ChucVu CV ON N.IdChucVu = CV.IdChucVu";

    private static final String SQL_GET_ALL_VIEW_TABLE_BY_PAGE = "SELECT N.*, CV.TenChucVu\n"
            + "FROM NhanVien N\n"
            + "LEFT JOIN ChucVu CV ON N.IdChucVu = CV.IdChucVu\n"
            + "ORDER BY N.IdNhanVien\n"
            + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    private static final String SQL_GET_LOGIN_INFO = "SELECT * FROM NhanVien WHERE maNhanVien = ? AND matKhau = ?";
    private static final String SQL_INSERT = "INSERT INTO NhanVien (MaNhanVien, TenNhanVien, Sdt, DiaChi, NgaySinh, GioiTinh, MatKhau, IdChucVu, TrangThai) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_GET_BY_ID = "SELECT * FROM NhanVien WHERE IdNhanVien = ?";
    private static final String SQL_GET_BY_MA = "SELECT * FROM NhanVien WHERE MaNhanVien = ?";

    private static final String SQL_GET_ALL_VIEW_TABLE_SEARCH = "SELECT N.*, CV.TenChucVu\n"
            + "FROM NhanVien N\n"
            + "LEFT JOIN ChucVu CV ON N.IdChucVu = CV.IdChucVu\n"
            + "WHERE CONCAT(CV.TenChucVu, ' ', N.TenNhanVien, ' ', N.Sdt, ' ', N.DiaChi, ' ', N.MaNhanVien) LIKE '%' + ? + '%'";

    private static final String SQL_UPDATE = "UPDATE NhanVien SET TenNhanVien=?, Sdt=?, DiaChi=?, NgaySinh=?, GioiTinh=?, MatKhau=?, IdChucVu=?, TrangThai=? WHERE IdNhanVien=?";

    private static final String COUNT_NHAN_VIEN = "SELECT COUNT(*) FROM NhanVien";
    public List<NhanVien> getAll() {
        List<NhanVien> nhanViens = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  Statement statement = connection.createStatement();  ResultSet resultSet = statement.executeQuery(SQL_GET_ALL)) {
            while (resultSet.next()) {
                NhanVien nhanVien = mapNhanVien(resultSet);

                nhanViens.add(nhanVien);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nhanViens;
    }

    public List<NhanVien> getAllViewTable() {
        List<NhanVien> nhanViens = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  Statement statement = connection.createStatement();  ResultSet resultSet = statement.executeQuery(SQL_GET_ALL_VIEW_TABLE)) {
            while (resultSet.next()) {
                NhanVien nhanVien = mapNhanVien(resultSet);
                nhanVien.setTenChucVu(resultSet.getString("tenChucVu"));
                nhanViens.add(nhanVien);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nhanViens;
    }
    
    public List<NhanVien> getAllViewTableSearch(String keyWord) {
        List<NhanVien> nhanViens = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_ALL_VIEW_TABLE_SEARCH)) {
            statement.setString(1, keyWord);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                NhanVien nhanVien = mapNhanVien(resultSet);
                nhanVien.setTenChucVu(resultSet.getString("tenChucVu"));
                nhanViens.add(nhanVien);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nhanViens;
    }
    
    public int getCountNhanVien() {
        int count = 0;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(COUNT_NHAN_VIEN)) {
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public List<NhanVien> getAllViewTableByPage(int offset, int limit) {
        List<NhanVien> nhanViens = new ArrayList<>();
        try ( Connection connection = JDBC.getConnection(); PreparedStatement statement = connection.prepareStatement(SQL_GET_ALL_VIEW_TABLE_BY_PAGE)) {
            statement.setInt(1, offset);
            statement.setInt(2, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                NhanVien nhanVien = mapNhanVien(resultSet);
                nhanVien.setTenChucVu(resultSet.getString("tenChucVu"));
                nhanViens.add(nhanVien);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nhanViens;
    }

    public NhanVien getNhanVienByIdNhanVien(String idNhanVien) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_ID)) {
            statement.setString(1, idNhanVien);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return mapNhanVien(resultSet);
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public NhanVien getNhanVienByMaNhanVien(String maNhanVien) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_MA)) {
            statement.setString(1, maNhanVien);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return mapNhanVien(resultSet);
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public NhanVien getLoginInfo(String maNhanVien, String matKhau) {
        NhanVien nhanVien = null;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_LOGIN_INFO)) {
            statement.setString(1, maNhanVien);
            statement.setString(2, matKhau);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                nhanVien = mapNhanVien(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nhanVien;
    }

    private NhanVien mapNhanVien(ResultSet resultSet) throws SQLException {
        NhanVien nhanVien = new NhanVien();
        nhanVien.setIdnhanVien(resultSet.getString("idnhanVien"));
        nhanVien.setMaNhanVien(resultSet.getString("maNhanVien"));
        nhanVien.setTenNhanVien(resultSet.getString("tenNhanVien"));
        nhanVien.setSdt(resultSet.getString("sdt"));
        nhanVien.setDiaChi(resultSet.getString("diaChi"));
        nhanVien.setNgaySinh(resultSet.getDate("ngaySinh"));
        nhanVien.setGioiTinh(resultSet.getString("gioiTinh"));
        nhanVien.setMatKhau(resultSet.getString("matKhau"));
        nhanVien.setIdchucVu(resultSet.getString("IdchucVu"));
        nhanVien.setTrangThai(resultSet.getString("trangThai"));
        return nhanVien;
    }

    public boolean themNhanVien(NhanVien nhanVien) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_INSERT)) {
            statement.setString(1, nhanVien.getMaNhanVien());
            statement.setString(2, nhanVien.getTenNhanVien());
            statement.setString(3, nhanVien.getSdt());
            statement.setString(4, nhanVien.getDiaChi());
            statement.setDate(5, new java.sql.Date(nhanVien.getNgaySinh().getTime()));
            statement.setString(6, nhanVien.getGioiTinh());
            statement.setString(7, nhanVien.getMatKhau());
            statement.setString(8, nhanVien.getIdchucVu());
            statement.setString(9, nhanVien.getTrangThai());
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean suaThongTinNhanVien(NhanVien nhanVien) {
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_UPDATE)) {
            statement.setString(1, nhanVien.getTenNhanVien());
            statement.setString(2, nhanVien.getSdt());
            statement.setString(3, nhanVien.getDiaChi());
            statement.setDate(4, new java.sql.Date(nhanVien.getNgaySinh().getTime()));
            statement.setString(5, nhanVien.getGioiTinh());
            statement.setString(6, nhanVien.getMatKhau());
            statement.setString(7, nhanVien.getIdchucVu());
            statement.setString(8, nhanVien.getTrangThai());
            statement.setString(9, nhanVien.getIdnhanVien());
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
