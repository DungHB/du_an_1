package com.asm.polybee.repository;

import com.asm.polybee.model.SanPham;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ultil.JDBC;

public class SanPhamRepository {

    private static final String SQL_GET_ALL = "SELECT sp.idSanPham, sp.maSanPham, sp.tenSanPham, tl.tenTheLoai, th.tenThuongHieu, sp.trangThai "
            + "FROM SanPham sp "
            + "JOIN TheLoai tl ON sp.idTheLoai = tl.idTheLoai "
            + "JOIN ThuongHieu th ON sp.idThuongHieu = th.idThuongHieu";
    
    private static final String SQL_GET_SEARCH = "SELECT sp.idSanPham, sp.maSanPham, sp.tenSanPham, tl.tenTheLoai, th.tenThuongHieu, sp.trangThai "
            + "FROM SanPham sp "
            + "JOIN TheLoai tl ON sp.idTheLoai = tl.idTheLoai "
            + "JOIN ThuongHieu th ON sp.idThuongHieu = th.idThuongHieu "
            + "WHERE CONCAT(sp.maSanPham, ' ', sp.tenSanPham, ' ', tl.tenTheLoai, ' ', th.tenThuongHieu) LIKE '%' + ? + '%'";

    private static final String SQL_GET_ALL_BY_PAGES = "SELECT sp.idSanPham, sp.maSanPham, sp.tenSanPham, tl.tenTheLoai, th.tenThuongHieu, sp.trangThai "
            + "FROM SanPham sp "
            + "JOIN TheLoai tl ON sp.idTheLoai = tl.idTheLoai "
            + "JOIN ThuongHieu th ON sp.idThuongHieu = th.idThuongHieu "
            + "ORDER BY sp.idSanPham "
            + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    private static final String SQL_GET_BY_ID = "SELECT idSanPham, maSanPham, tenSanPham, idTheLoai, idThuongHieu, trangThai "
            + "FROM SanPham "
            + "WHERE idSanPham = ?";

    private static final String SQL_GET_BY_MA = "SELECT idSanPham, maSanPham, tenSanPham, idTheLoai, idThuongHieu, trangThai "
            + "FROM SanPham "
            + "WHERE maSanPham = ?";

    private static final String COUNT_SAN_PHAM = "SELECT COUNT(*) FROM SanPham";

    public List<SanPham> getAll() {
        List<SanPham> sanPhams = new ArrayList<>();

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_ALL)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                SanPham sanPham = new SanPham();
                sanPham.setIdSanPham(resultSet.getString("idSanPham"));
                sanPham.setMaSanPham(resultSet.getString("maSanPham"));
                sanPham.setTenSanPham(resultSet.getString("tenSanPham"));
                sanPham.setIdTheLoai(resultSet.getString("tenTheLoai"));
                sanPham.setIdThuongHieu(resultSet.getString("tenThuongHieu"));
                sanPham.setTrangThai(resultSet.getString("trangThai"));
                sanPhams.add(sanPham);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sanPhams;
    }
    
    public List<SanPham> getSearchSP(String keyWordSP) {
        List<SanPham> sanPhams = new ArrayList<>();

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_SEARCH)) {
            statement.setString(1, keyWordSP);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                SanPham sanPham = new SanPham();
                sanPham.setIdSanPham(resultSet.getString("idSanPham"));
                sanPham.setMaSanPham(resultSet.getString("maSanPham"));
                sanPham.setTenSanPham(resultSet.getString("tenSanPham"));
                sanPham.setIdTheLoai(resultSet.getString("tenTheLoai"));
                sanPham.setIdThuongHieu(resultSet.getString("tenThuongHieu"));
                sanPham.setTrangThai(resultSet.getString("trangThai"));
                sanPhams.add(sanPham);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sanPhams;
    }

    public int getCountSanPham() {
        int count = 0;
        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(COUNT_SAN_PHAM)) {
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public List<SanPham> getAllByPages(int offset, int limit) {
        List<SanPham> sanPhams = new ArrayList<>();

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_ALL_BY_PAGES)) {
            statement.setInt(1, offset);
            statement.setInt(2, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                SanPham sanPham = new SanPham();
                sanPham.setIdSanPham(resultSet.getString("idSanPham"));
                sanPham.setMaSanPham(resultSet.getString("maSanPham"));
                sanPham.setTenSanPham(resultSet.getString("tenSanPham"));
                sanPham.setIdTheLoai(resultSet.getString("tenTheLoai"));
                sanPham.setIdThuongHieu(resultSet.getString("tenThuongHieu"));
                sanPham.setTrangThai(resultSet.getString("trangThai"));
                sanPhams.add(sanPham);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sanPhams;
    }

    public void themSanPham(SanPham sanPham) {
        String sql = "INSERT INTO SanPham (maSanPham, tenSanPham, idTheLoai, idThuongHieu, trangThai) VALUES (?, ?, ?, ?, ?)";

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, sanPham.getMaSanPham());
            statement.setString(2, sanPham.getTenSanPham());
            statement.setString(3, sanPham.getIdTheLoai());
            statement.setString(4, sanPham.getIdThuongHieu());
            statement.setString(5, sanPham.getTrangThai());

            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Thêm sản phẩm thành công!");
            } else {
                System.out.println("Thêm sản phẩm thất bại!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void capNhatSanPham(SanPham sanPham) {
        String sql = "UPDATE SanPham SET maSanPham = ?, tenSanPham = ?, idTheLoai = ?, idThuongHieu = ?, trangThai = ? WHERE idSanPham = ?";

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, sanPham.getMaSanPham());
            statement.setString(2, sanPham.getTenSanPham());
            statement.setString(3, sanPham.getIdTheLoai());
            statement.setString(4, sanPham.getIdThuongHieu());
            statement.setString(5, sanPham.getTrangThai());
            statement.setString(6, sanPham.getIdSanPham());
            

            int affectedRows = statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public SanPham layThongTinSanPhamTheoId(String idSanPham) {
        SanPham sanPham = null;

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_ID)) {
            // Đặt tham số idSanPham vào câu lệnh SQL
            statement.setString(1, idSanPham);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                sanPham = new SanPham();
                sanPham.setIdSanPham(resultSet.getString("idSanPham"));
                sanPham.setMaSanPham(resultSet.getString("maSanPham"));
                sanPham.setTenSanPham(resultSet.getString("tenSanPham"));
                sanPham.setIdTheLoai(resultSet.getString("idTheLoai"));
                sanPham.setIdThuongHieu(resultSet.getString("idThuongHieu"));
                sanPham.setTrangThai(resultSet.getString("trangThai"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sanPham;
    }

    public SanPham layThongTinSanPhamTheoMa(String maSanPham) {
        SanPham sanPham = null;

        try ( Connection connection = JDBC.getConnection();  PreparedStatement statement = connection.prepareStatement(SQL_GET_BY_MA)) {
            // Đặt tham số idSanPham vào câu lệnh SQL
            statement.setString(1, maSanPham);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                sanPham = new SanPham();
                sanPham.setIdSanPham(resultSet.getString("idSanPham"));
                sanPham.setMaSanPham(resultSet.getString("maSanPham"));
                sanPham.setTenSanPham(resultSet.getString("tenSanPham"));
                sanPham.setIdTheLoai(resultSet.getString("idTheLoai"));
                sanPham.setIdThuongHieu(resultSet.getString("idThuongHieu"));
                sanPham.setTrangThai(resultSet.getString("trangThai"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sanPham;
    }

}
